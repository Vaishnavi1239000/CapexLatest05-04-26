import "./advanced.scss";
declare const EditAdvanceForm: ({ context, formData, onClose }: any) => JSX.Element;
export default EditAdvanceForm;
//# sourceMappingURL=EditAdvanceForm.d.ts.map