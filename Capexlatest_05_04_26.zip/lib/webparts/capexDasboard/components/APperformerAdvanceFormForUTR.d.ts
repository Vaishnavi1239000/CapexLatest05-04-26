import * as React from "react";
import "./advanced.scss";
interface IProps {
    context: any;
    itemId: number;
}
declare const APperformerAdvanceFormForUTR: React.FC<IProps>;
export default APperformerAdvanceFormForUTR;
//# sourceMappingURL=APperformerAdvanceFormForUTR.d.ts.map