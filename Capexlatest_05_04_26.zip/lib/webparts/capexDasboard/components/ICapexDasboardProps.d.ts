import { WebPartContext } from "@microsoft/sp-webpart-base";
export interface ICapexDasboardProps {
    description: string;
    isDarkTheme: boolean;
    environmentMessage: string;
    hasTeamsContext: boolean;
    userDisplayName: string;
    context: WebPartContext;
}
//# sourceMappingURL=ICapexDasboardProps.d.ts.map