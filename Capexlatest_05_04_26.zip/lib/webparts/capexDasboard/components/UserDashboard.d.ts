import * as React from "react";
import "./userDashboardsc.scss";
import "../assets/bootstrap/css/bootstrap.css";
interface UserDashboardProps {
    context: any;
}
declare const UserDashboard: React.FC<UserDashboardProps>;
export default UserDashboard;
//# sourceMappingURL=UserDashboard.d.ts.map