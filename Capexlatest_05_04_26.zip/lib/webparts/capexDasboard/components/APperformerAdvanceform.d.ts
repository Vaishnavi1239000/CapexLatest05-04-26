import * as React from "react";
import "./advanced.scss";
interface IProps {
    context: any;
    itemId: number;
}
declare const APperformerAdvanceform: React.FC<IProps>;
export default APperformerAdvanceform;
//# sourceMappingURL=APperformerAdvanceform.d.ts.map