import "./advanced.scss";
declare const NewAdvanceform: ({ context }: any) => JSX.Element;
export default NewAdvanceform;
//# sourceMappingURL=NewAdvanceform.d.ts.map