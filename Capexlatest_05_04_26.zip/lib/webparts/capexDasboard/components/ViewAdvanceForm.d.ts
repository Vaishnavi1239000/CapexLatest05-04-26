import "./advanced.scss";
declare const ViewAdvanceForm: ({ context, formData, onClose }: any) => JSX.Element;
export default ViewAdvanceForm;
//# sourceMappingURL=ViewAdvanceForm.d.ts.map