import './usersite.scss';
import { ICapexDasboardProps } from './ICapexDasboardProps';
export default function CapexDasboard(props: ICapexDasboardProps): JSX.Element;
//# sourceMappingURL=CapexDasboard.d.ts.map