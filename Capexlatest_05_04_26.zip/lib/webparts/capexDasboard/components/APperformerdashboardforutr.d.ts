import * as React from "react";
import "./userDashboardsc.scss";
import "../assets/bootstrap/css/bootstrap.css";
interface UserDashboardProps {
    context: any;
}
declare const APperformerdashboardforutr: React.FC<UserDashboardProps>;
export default APperformerdashboardforutr;
//# sourceMappingURL=APperformerdashboardforutr.d.ts.map