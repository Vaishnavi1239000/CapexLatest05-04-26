"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.default = PerformerDasboard;
var tslib_1 = require("tslib");
var React = tslib_1.__importStar(require("react"));
function PerformerDasboard() {
    return (React.createElement("div", { style: { padding: "30px" } },
        React.createElement("h3", { style: { color: "red" } }, "Manage Access")));
}
//# sourceMappingURL=PerformerDasboard.js.map