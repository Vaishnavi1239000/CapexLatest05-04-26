"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var tslib_1 = require("tslib");
var React = tslib_1.__importStar(require("react"));
require("./advanced.scss");
var sp_1 = require("@pnp/sp");
var all_1 = require("@pnp/sp/presets/all");
var react_1 = require("react");
var PeoplePicker_1 = require("@pnp/spfx-controls-react/lib/PeoplePicker");
var NewAdvanceform = function (_a) {
    var _b, _c;
    var context = _a.context;
    var sp = (0, sp_1.spfi)().using((0, all_1.SPFx)(context));
    var _d = (0, react_1.useState)([]), attachments = _d[0], setAttachments = _d[1];
    var _e = (0, react_1.useState)([]), selectedFiles = _e[0], setSelectedFiles = _e[1];
    var _f = React.useState({}), employee = _f[0], setEmployee = _f[1];
    //const [selectedUser, setSelectedUser] = useState<any>(null);
    //const [attachments, setAttachments] = useState<File[]>([]);
    var _g = (0, react_1.useState)([]), previousAdvances = _g[0], setPreviousAdvances = _g[1];
    var _h = React.useState(""), employeeName = _h[0], setEmployeeName = _h[1];
    var _j = React.useState(0), pickerKey = _j[0], setPickerKey = _j[1];
    var _k = (0, react_1.useState)([]), vendors = _k[0], setVendors = _k[1];
    var _l = (0, react_1.useState)([]), selectedUser = _l[0], setSelectedUser = _l[1];
    var _m = (0, react_1.useState)(null), selectedVendorId = _m[0], setSelectedVendorId = _m[1];
    var _o = (0, react_1.useState)(""), selectedVendorName = _o[0], setSelectedVendorName = _o[1];
    var _p = (0, react_1.useState)(""), poAmount = _p[0], setPoAmount = _p[1];
    var _q = (0, react_1.useState)(""), advanceAmount = _q[0], setAdvanceAmount = _q[1];
    var _r = (0, react_1.useState)(""), paidAmount = _r[0], setPaidAmount = _r[1];
    var _s = (0, react_1.useState)(""), poNumber = _s[0], setPoNumber = _s[1];
    var _t = (0, react_1.useState)(""), poDate = _t[0], setPoDate = _t[1];
    var _u = (0, react_1.useState)(""), poTerms = _u[0], setPoTerms = _u[1];
    var _v = (0, react_1.useState)(""), expectedDate = _v[0], setExpectedDate = _v[1];
    var _w = (0, react_1.useState)("390111003"), glCode = _w[0], setGlCode = _w[1];
    var _x = (0, react_1.useState)(""), costCenter = _x[0], setCostCenter = _x[1];
    var _y = (0, react_1.useState)(""), remarks = _y[0], setRemarks = _y[1];
    var _z = (0, react_1.useState)(""), projectDesc = _z[0], setProjectDesc = _z[1];
    var _0 = (0, react_1.useState)([]), approvalMatrix = _0[0], setApprovalMatrix = _0[1];
    var peoplePickerContext = {
        absoluteUrl: context.pageContext.web.absoluteUrl,
        msGraphClientFactory: context.msGraphClientFactory,
        spHttpClient: context.spHttpClient,
    };
    var handleNumberChange = function (value, setter) {
        // Allow only numbers and decimal (max one dot)
        var regex = /^\d*\.?\d*$/;
        if (regex.test(value)) {
            void setter(value);
        }
    };
    var getPreviousAdvances = function (vendorId) { return tslib_1.__awaiter(void 0, void 0, void 0, function () {
        var data, error_1;
        return tslib_1.__generator(this, function (_a) {
            switch (_a.label) {
                case 0:
                    _a.trys.push([0, 2, , 3]);
                    debugger;
                    console.log("Fetching for Vendor:", vendorId);
                    return [4 /*yield*/, sp.web.lists
                            .getByTitle("CapexAdvance")
                            .items.select("PONumber", "RequestAdvanceAmount", "Created", "VoucherDate", "PaidAmount", "Status", "VendorCode/Id")
                            .expand("VendorCode")
                            .filter("VendorCode/Id eq ".concat(vendorId, " and Status eq 'Paid'"))
                            .orderBy("Created", false)()];
                case 1:
                    data = _a.sent();
                    console.log("DATA:", data);
                    void setPreviousAdvances(data);
                    return [3 /*break*/, 3];
                case 2:
                    error_1 = _a.sent();
                    console.error("Error fetching previous advances:", error_1);
                    void setPreviousAdvances([]);
                    return [3 /*break*/, 3];
                case 3: return [2 /*return*/];
            }
        });
    }); };
    var handleRemoveFile = function (index) {
        var updatedFiles = tslib_1.__spreadArray([], selectedFiles, true);
        updatedFiles.splice(index, 1);
        setSelectedFiles(updatedFiles);
    };
    var handleExit = function () {
        window.location.href =
            "https://isriglobal.sharepoint.com/sites/SonaFinance/SitePages/CapexForm.aspx?page=User";
    };
    var getLoggedInUser = function () { return tslib_1.__awaiter(void 0, void 0, void 0, function () {
        var currentUser, email, user, error_2;
        return tslib_1.__generator(this, function (_a) {
            switch (_a.label) {
                case 0:
                    _a.trys.push([0, 3, , 4]);
                    return [4 /*yield*/, sp.web.currentUser()];
                case 1:
                    currentUser = _a.sent();
                    email = currentUser.Email;
                    return [4 /*yield*/, sp.web.lists
                            .getByTitle("EmployeeMaster")
                            .items.select("EmployeeCode", "EmployeeName", "Division", "Location", "EmployeeEmail", "ReportingManager/Title", "ReportingManager/Id", "HOD/Title", "HOD/Id", "ContactNo", "EmployeeStatus", "CostCenter")
                            .expand("ReportingManager", "HOD")
                            .filter("EmployeeEmail eq '".concat(email, "'"))
                            .top(1)()];
                case 2:
                    user = _a.sent();
                    if (user.length > 0) {
                        void setEmployee(user[0]);
                    }
                    return [3 /*break*/, 4];
                case 3:
                    error_2 = _a.sent();
                    console.log("Error fetching user:", error_2);
                    return [3 /*break*/, 4];
                case 4: return [2 /*return*/];
            }
        });
    }); };
    var getVendors = function () { return tslib_1.__awaiter(void 0, void 0, void 0, function () {
        var data;
        return tslib_1.__generator(this, function (_a) {
            switch (_a.label) {
                case 0: return [4 /*yield*/, sp.web.lists
                        .getByTitle("VendorMaster")
                        .items.select("Id", "VendorCode", "VendorName")()];
                case 1:
                    data = _a.sent();
                    void setVendors(data);
                    return [2 /*return*/];
            }
        });
    }); };
    var getFinancialYear = function () {
        var today = new Date();
        var year = today.getFullYear();
        var month = today.getMonth() + 1;
        if (month >= 4) {
            // April to March
            return "".concat(year.toString().slice(-2), "-").concat((year + 1).toString().slice(-2));
        }
        else {
            return "".concat((year - 1).toString().slice(-2), "-").concat(year.toString().slice(-2));
        }
    };
    var generateCapexId = function () { return tslib_1.__awaiter(void 0, void 0, void 0, function () {
        var fy, items, nextNumber, lastId, parts, lastNumber, formattedNumber, error_3;
        return tslib_1.__generator(this, function (_a) {
            switch (_a.label) {
                case 0:
                    _a.trys.push([0, 2, , 3]);
                    fy = getFinancialYear();
                    return [4 /*yield*/, sp.web.lists
                            .getByTitle("CapexAdvance")
                            .items.select("CapexID", "ID")
                            .filter("startswith(CapexID,'CPX/".concat(fy, "/')"))
                            .orderBy("ID", false)
                            .top(1)()];
                case 1:
                    items = _a.sent();
                    nextNumber = 1;
                    if (items.length > 0 && items[0].CapexID) {
                        lastId = items[0].CapexID;
                        parts = lastId.split("/");
                        if (parts.length === 3) {
                            lastNumber = parseInt(parts[2]);
                            if (!isNaN(lastNumber)) {
                                nextNumber = lastNumber + 1;
                            }
                        }
                    }
                    formattedNumber = nextNumber.toString().padStart(5, "0");
                    return [2 /*return*/, "CPX/".concat(fy, "/").concat(formattedNumber)];
                case 2:
                    error_3 = _a.sent();
                    alert(error_3);
                    console.error("Capex ID Error:", error_3);
                    return [2 /*return*/, "CPX/".concat(getFinancialYear(), "/00001")];
                case 3: return [2 /*return*/];
            }
        });
    }); };
    var uploadAttachments = function (capexId) { return tslib_1.__awaiter(void 0, void 0, void 0, function () {
        var safeCapexId, libraryName, webUrl, folderPath, _i, selectedFiles_1, file, error_4;
        return tslib_1.__generator(this, function (_a) {
            switch (_a.label) {
                case 0:
                    _a.trys.push([0, 6, , 7]);
                    if (!selectedFiles || selectedFiles.length === 0)
                        return [2 /*return*/];
                    safeCapexId = capexId.replace(/\//g, "_");
                    libraryName = "CapexAdvanceDocs";
                    webUrl = context.pageContext.web.serverRelativeUrl;
                    folderPath = "".concat(webUrl, "/").concat(libraryName, "/").concat(safeCapexId);
                    // ✅ Ensure folder
                    return [4 /*yield*/, sp.web.folders.addUsingPath("".concat(libraryName, "/").concat(safeCapexId))];
                case 1:
                    // ✅ Ensure folder
                    _a.sent();
                    _i = 0, selectedFiles_1 = selectedFiles;
                    _a.label = 2;
                case 2:
                    if (!(_i < selectedFiles_1.length)) return [3 /*break*/, 5];
                    file = selectedFiles_1[_i];
                    return [4 /*yield*/, sp.web
                            .getFolderByServerRelativePath(folderPath)
                            .files.addUsingPath(file.name, file, { Overwrite: true })];
                case 3:
                    _a.sent();
                    _a.label = 4;
                case 4:
                    _i++;
                    return [3 /*break*/, 2];
                case 5:
                    console.log("✅ Files uploaded successfully");
                    return [3 /*break*/, 7];
                case 6:
                    error_4 = _a.sent();
                    console.error("❌ Upload error:", error_4);
                    return [3 /*break*/, 7];
                case 7: return [2 /*return*/];
            }
        });
    }); };
    var buildApprovalFlow = function () { return tslib_1.__awaiter(void 0, void 0, void 0, function () {
        var flow_1, matrixData, matrixApprovers, fullFlow, uniqueFlow, error_5;
        var _a, _b, _c, _d, _e;
        return tslib_1.__generator(this, function (_f) {
            switch (_f.label) {
                case 0:
                    _f.trys.push([0, 2, , 3]);
                    flow_1 = [];
                    // =========================
                    // 🔹 RM
                    // =========================
                    if ((_a = employee.ReportingManager) === null || _a === void 0 ? void 0 : _a.Id) {
                        flow_1.push({
                            Id: employee.ReportingManager.Id,
                            Name: (_b = employee.ReportingManager) === null || _b === void 0 ? void 0 : _b.Title,
                            Role: "RM",
                            Level: 1,
                            Status: "Pending",
                        });
                    }
                    // =========================
                    // 🔹 HOD
                    // =========================
                    if ((_c = employee.HOD) === null || _c === void 0 ? void 0 : _c.Id) {
                        flow_1.push({
                            Id: (_d = employee.HOD) === null || _d === void 0 ? void 0 : _d.Id,
                            Name: (_e = employee.HOD) === null || _e === void 0 ? void 0 : _e.Title,
                            Role: "HOD",
                            Level: 2,
                            Status: "Pending",
                        });
                    }
                    return [4 /*yield*/, sp.web.lists
                            .getByTitle("CapexApprovalMatrix")
                            .items.select("Role/RoleName,Level/Level,Approver/Id,Approver/Title")
                            .expand("Approver,Role,Level")
                            .filter("Status eq 'Active'")
                            .orderBy("Level", true)()];
                case 1:
                    matrixData = _f.sent();
                    matrixApprovers = matrixData.map(function (item, index) {
                        var _a, _b;
                        return ({
                            Id: (_a = item.Approver) === null || _a === void 0 ? void 0 : _a.Id,
                            Name: (_b = item.Approver) === null || _b === void 0 ? void 0 : _b.Title,
                            Role: item.Role.RoleName,
                            Level: flow_1.length + index + 1,
                            Status: "Pending",
                        });
                    });
                    fullFlow = tslib_1.__spreadArray(tslib_1.__spreadArray([], flow_1, true), matrixApprovers, true);
                    uniqueFlow = fullFlow.filter(function (v, i, self) { return self.findIndex(function (x) { return x.Id === v.Id; }) === i; });
                    return [2 /*return*/, uniqueFlow];
                case 2:
                    error_5 = _f.sent();
                    console.error("Approval Flow Error:", error_5);
                    return [2 /*return*/, []];
                case 3: return [2 /*return*/];
            }
        });
    }); };
    (0, react_1.useEffect)(function () {
        var loadFlow = function () { return tslib_1.__awaiter(void 0, void 0, void 0, function () {
            var flow, error_6;
            return tslib_1.__generator(this, function (_a) {
                switch (_a.label) {
                    case 0:
                        if (!(employee && employee.ReportingManager)) return [3 /*break*/, 4];
                        _a.label = 1;
                    case 1:
                        _a.trys.push([1, 3, , 4]);
                        return [4 /*yield*/, buildApprovalFlow()];
                    case 2:
                        flow = _a.sent();
                        setApprovalMatrix(flow);
                        return [3 /*break*/, 4];
                    case 3:
                        error_6 = _a.sent();
                        console.error(error_6);
                        return [3 /*break*/, 4];
                    case 4: return [2 /*return*/];
                }
            });
        }); };
        void loadFlow();
    }, [employee]);
    // useEffect(() => {
    //   if (employee && employee.ReportingManager) {
    //     buildApprovalFlow().then(setApprovalMatrix);
    //   }
    // }, [employee]);
    var validateForm = function () {
        var errors = [];
        if (!selectedVendorId) {
            errors.push("Please select the Vendor code");
        }
        if (!poNumber) {
            errors.push("Please update PO Number");
        }
        if (!poDate) {
            errors.push("Please update PO date");
        }
        if (!poTerms) {
            errors.push("Please update PO Terms");
        }
        if (!poAmount) {
            errors.push("Please update PO Amount");
        }
        if (!advanceAmount || Number(advanceAmount) <= 0) {
            errors.push("Please update Advance Amount");
        }
        if (!paidAmount || Number(paidAmount) <= 0) {
            errors.push("Please update Paid Amount");
        }
        // 🔥 NEW VALIDATION
        if (advanceAmount &&
            paidAmount &&
            Number(paidAmount) > Number(advanceAmount)) {
            errors.push("Paid Amount cannot be greater than Advance Amount");
        }
        if (!expectedDate) {
            errors.push("Please update Settlement Date");
        }
        if (!selectedUser || selectedUser.length === 0) {
            errors.push("Please select PIC Name");
        }
        if (!projectDesc) {
            errors.push("Please enter Project Description");
        }
        if (!selectedFiles || selectedFiles.length === 0) {
            errors.push("Please upload at least one attachment");
        }
        return errors;
    };
    var handleSubmit = function () { return tslib_1.__awaiter(void 0, void 0, void 0, function () {
        var errors, capexId, userEmail, ensuredUser, flow, currentApprover, currentUser, wfHistory, error_7;
        var _a, _b, _c, _d, _e;
        return tslib_1.__generator(this, function (_f) {
            switch (_f.label) {
                case 0:
                    _f.trys.push([0, 6, , 7]);
                    debugger;
                    errors = validateForm();
                    if (errors.length > 0) {
                        alert(errors.join("\n")); // 👈 shows exactly like your screenshot
                        return [2 /*return*/];
                    }
                    return [4 /*yield*/, generateCapexId()];
                case 1:
                    capexId = _f.sent();
                    userEmail = (_a = selectedUser[0]) === null || _a === void 0 ? void 0 : _a.secondaryText;
                    if (!userEmail) {
                        alert("User email not found");
                        return [2 /*return*/];
                    }
                    return [4 /*yield*/, sp.web.ensureUser(userEmail)];
                case 2:
                    ensuredUser = _f.sent();
                    return [4 /*yield*/, buildApprovalFlow()];
                case 3:
                    flow = _f.sent();
                    // 🔥 Set first approver as current
                    if (flow.length > 0) {
                        flow[0].Status = "In Progress";
                    }
                    currentApprover = flow.length > 0 ? flow[0].Id : null;
                    currentUser = ((_c = (_b = context.pageContext) === null || _b === void 0 ? void 0 : _b.user) === null || _c === void 0 ? void 0 : _c.displayName) || "User";
                    wfHistory = [
                        {
                            CurrentApprover: currentUser,
                            ActionTaken: "Submitted",
                            Comment: remarks || "",
                            Date: new Date().toISOString(),
                        },
                    ];
                    return [4 /*yield*/, sp.web.lists.getByTitle("CapexAdvance").items.add({
                            Title: capexId,
                            CapexID: capexId,
                            // Employee
                            EmployeeCode: employee.EmployeeCode,
                            EmployeeName: employee.EmployeeName,
                            Division: employee.Division,
                            Location: employee.Location,
                            Email: employee.EmployeeEmail,
                            RM: (_d = employee.ReportingManager) === null || _d === void 0 ? void 0 : _d.Title,
                            HOD: (_e = employee.HOD) === null || _e === void 0 ? void 0 : _e.Title,
                            ContactNo: employee.ContactNo,
                            EmployeeStatus: employee.EmployeeStatus,
                            // Vendor (LOOKUP)
                            VendorCodeId: selectedVendorId, // ✅ FIX
                            VendorName: selectedVendorName,
                            // PO
                            PONumber: poNumber,
                            PODate: poDate ? new Date(poDate) : null,
                            POAdvanceTerms: poTerms,
                            // Amount
                            POAmtGST: poAmount,
                            RequestAdvanceAmount: advanceAmount,
                            PaidAmount: paidAmount,
                            // Advance
                            ExpectedDateofSettlement: expectedDate ? new Date(expectedDate) : null,
                            // Person field
                            PICNameId: ensuredUser.Id, // ✅ FIX
                            // Other
                            GL: glCode,
                            CostCenter: employee.CostCenter,
                            Remarks: remarks,
                            ProjectDescription: projectDesc,
                            Status: "Pending for Approver",
                            ApprovalMatrix: JSON.stringify(flow),
                            CurrentApproverId: currentApprover,
                            WorkFlowHistory: JSON.stringify(wfHistory),
                        })];
                case 4:
                    _f.sent();
                    debugger;
                    return [4 /*yield*/, uploadAttachments(capexId)];
                case 5:
                    _f.sent(); // 🔥 FIXED
                    console.log("Attachments:", selectedFiles);
                    alert("Submitted successfully ✅");
                    // 🔥 REDIRECT
                    window.location.href =
                        "https://isriglobal.sharepoint.com/sites/SonaFinance/SitePages/CapexForm.aspx?page=User";
                    return [3 /*break*/, 7];
                case 6:
                    error_7 = _f.sent();
                    console.error("ERROR:", error_7);
                    alert("Error while saving ❌");
                    return [3 /*break*/, 7];
                case 7: return [2 /*return*/];
            }
        });
    }); };
    var handledraft = function () { return tslib_1.__awaiter(void 0, void 0, void 0, function () {
        var capexId, ensuredUserId, userEmail_1, ensuredUser_1, userEmail, ensuredUser, flow, currentApprover, currentUser, wfHistory, safeCapexId, error_8;
        var _a, _b, _c, _d, _e, _f;
        return tslib_1.__generator(this, function (_g) {
            switch (_g.label) {
                case 0:
                    _g.trys.push([0, 7, , 8]);
                    return [4 /*yield*/, generateCapexId()];
                case 1:
                    capexId = _g.sent();
                    ensuredUserId = null;
                    if (!(selectedUser && selectedUser.length > 0)) return [3 /*break*/, 3];
                    userEmail_1 = (_a = selectedUser[0]) === null || _a === void 0 ? void 0 : _a.secondaryText;
                    if (!userEmail_1) return [3 /*break*/, 3];
                    return [4 /*yield*/, sp.web.ensureUser(userEmail_1)];
                case 2:
                    ensuredUser_1 = _g.sent();
                    ensuredUserId = ensuredUser_1.Id;
                    _g.label = 3;
                case 3:
                    userEmail = (_b = selectedUser[0]) === null || _b === void 0 ? void 0 : _b.secondaryText;
                    if (!userEmail) {
                        alert("User email not found");
                        return [2 /*return*/];
                    }
                    return [4 /*yield*/, sp.web.ensureUser(userEmail)];
                case 4:
                    ensuredUser = _g.sent();
                    return [4 /*yield*/, buildApprovalFlow()];
                case 5:
                    flow = _g.sent();
                    // 🔥 Set first approver as current
                    if (flow.length > 0) {
                        flow[0].Status = "In Progress";
                    }
                    currentApprover = flow.length > 0 ? flow[0].Id : null;
                    currentUser = ((_d = (_c = context.pageContext) === null || _c === void 0 ? void 0 : _c.user) === null || _d === void 0 ? void 0 : _d.displayName) || "User";
                    wfHistory = [
                        {
                            CurrentApprover: currentUser,
                            ActionTaken: "Submitted",
                            Comment: remarks || "",
                            Date: new Date().toISOString(),
                        },
                    ];
                    return [4 /*yield*/, sp.web.lists.getByTitle("CapexAdvance").items.add(tslib_1.__assign(tslib_1.__assign({ Title: capexId, CapexID: capexId, 
                            // Employee
                            EmployeeCode: employee.EmployeeCode, EmployeeName: employee.EmployeeName, Division: employee.Division, Location: employee.Location, Email: employee.EmployeeEmail, RM: (_e = employee.ReportingManager) === null || _e === void 0 ? void 0 : _e.Title, HOD: (_f = employee.HOD) === null || _f === void 0 ? void 0 : _f.Title, ContactNo: employee.ContactNo, EmployeeStatus: employee.EmployeeStatus, 
                            // Vendor
                            VendorCodeId: selectedVendorId, VendorName: selectedVendorName, 
                            // PO
                            PONumber: poNumber, PODate: poDate ? new Date(poDate) : null, POAdvanceTerms: poTerms, 
                            // Amount
                            POAmtGST: poAmount, RequestAdvanceAmount: advanceAmount, PaidAmount: paidAmount, 
                            // Advance
                            ExpectedDateofSettlement: expectedDate ? new Date(expectedDate) : null }, (ensuredUserId && { PICNameId: ensuredUserId })), { 
                            // Other
                            GL: glCode, CostCenter: employee.CostCenter, Remarks: remarks, ProjectDescription: projectDesc, Status: "Draft", ApprovalMatrix: JSON.stringify(flow), CurrentApproverId: currentApprover, WorkFlowHistory: JSON.stringify(wfHistory) }))];
                case 6:
                    _g.sent();
                    safeCapexId = capexId.replace(/\//g, "_");
                    void uploadAttachments(safeCapexId);
                    alert("Draft saved successfully ✅");
                    window.location.href =
                        "https://isriglobal.sharepoint.com/sites/SonaFinance/SitePages/CapexForm.aspx?page=User";
                    return [3 /*break*/, 8];
                case 7:
                    error_8 = _g.sent();
                    console.error("ERROR:", error_8);
                    alert("Error while saving ❌");
                    return [3 /*break*/, 8];
                case 8: return [2 /*return*/];
            }
        });
    }); };
    React.useEffect(function () {
        if (!context)
            return;
        void getLoggedInUser();
        void getVendors(); // 👈 ADD THIS
    }, [context]);
    return (React.createElement("div", { className: "form-container" },
        React.createElement("h2", { className: "form-title" }, "(New advanceed)Advance Payment"),
        React.createElement("div", { className: "approval-flow" }, approvalMatrix.map(function (a, index) { return (React.createElement("div", { key: index, className: "approval-step" },
            React.createElement("div", null,
                React.createElement("b", null, a.Role)),
            React.createElement("div", null, a.Name),
            React.createElement("div", { style: {
                    color: a.Status === "Approved"
                        ? "green"
                        : a.Status === "Rejected"
                            ? "red"
                            : a.Status === "In Progress"
                                ? "orange"
                                : "gray",
                } }, a.Status))); })),
        React.createElement("div", { className: "section" },
            React.createElement("h3", null, "Requestor Information"),
            React.createElement("div", { className: "form-row" },
                React.createElement("label", null, "Employee Code"),
                React.createElement("input", { value: employee.EmployeeCode || "", readOnly: true }),
                React.createElement("label", null, "Employee Name"),
                React.createElement("input", { value: employee.EmployeeName || "", readOnly: true }),
                React.createElement("label", null, "Division"),
                React.createElement("input", { value: employee.Division || "", readOnly: true }),
                React.createElement("label", null, "Location"),
                React.createElement("input", { value: employee.Location || "", readOnly: true })),
            React.createElement("div", { className: "form-row" },
                React.createElement("label", null, "Email"),
                React.createElement("input", { value: employee.EmployeeEmail || "", readOnly: true }),
                React.createElement("label", null, "RM"),
                React.createElement("input", { value: ((_b = employee.ReportingManager) === null || _b === void 0 ? void 0 : _b.Title) || "", readOnly: true }),
                React.createElement("label", null, "HOD"),
                React.createElement("input", { value: ((_c = employee.HOD) === null || _c === void 0 ? void 0 : _c.Title) || "", readOnly: true }),
                React.createElement("label", null, "Contact No"),
                React.createElement("input", { value: employee.ContactNo || "", readOnly: true })),
            React.createElement("div", { className: "form-row" },
                React.createElement("label", null, "Employee Status"),
                React.createElement("input", { value: employee.EmployeeStatus || "", readOnly: true }))),
        React.createElement("div", { className: "section" },
            React.createElement("h3", null, "Vendor & PO Details"),
            React.createElement("div", { className: "form-row" },
                React.createElement("label", null, "Vendor Code"),
                React.createElement("select", { value: selectedVendorId || "", onChange: function (e) {
                        var id = Number(e.target.value);
                        var vendor = vendors.find(function (v) { return v.Id === id; });
                        setSelectedVendorId(id);
                        setSelectedVendorName((vendor === null || vendor === void 0 ? void 0 : vendor.VendorName) || "");
                        // 🔥 FETCH DATA
                        if (id) {
                            void getPreviousAdvances(id);
                        }
                    } },
                    React.createElement("option", { value: "" }, "Select Vendor"),
                    vendors.map(function (v) { return (React.createElement("option", { key: v.Id, value: v.Id }, v.VendorCode)); })),
                React.createElement("br", null),
                React.createElement("label", null, "Vendor Name"),
                React.createElement("input", { value: selectedVendorName, readOnly: true }),
                React.createElement("label", null, "PO Number"),
                React.createElement("input", { value: poNumber, onChange: function (e) { return setPoNumber(e.target.value); } }),
                React.createElement("label", null, "PO Date"),
                React.createElement("input", { type: "date", value: poDate, onChange: function (e) { return setPoDate(e.target.value); } })),
            React.createElement("div", { className: "form-row" },
                React.createElement("label", null, "PO Advance Terms"),
                React.createElement("input", { value: poTerms, onChange: function (e) { return setPoTerms(e.target.value); } }),
                React.createElement("label", null, "PO Amount (GST)"),
                React.createElement("input", { value: poAmount, onChange: function (e) { return handleNumberChange(e.target.value, setPoAmount); } }),
                React.createElement("label", null, "Request Advance Amount"),
                React.createElement("input", { value: advanceAmount, onChange: function (e) {
                        return handleNumberChange(e.target.value, setAdvanceAmount);
                    } }),
                React.createElement("label", { style: { color: "red" } }, "Paid Amount"),
                React.createElement("input", { value: paidAmount, onChange: function (e) { return handleNumberChange(e.target.value, setPaidAmount); } }))),
        React.createElement("div", { className: "section" },
            React.createElement("h3", null, "Advance Details"),
            React.createElement("div", { className: "form-row" },
                React.createElement("label", null, "Expected Settlement Date"),
                React.createElement("input", { type: "date", value: expectedDate, onChange: function (e) { return setExpectedDate(e.target.value); } }),
                React.createElement("label", null, "PIC Name"),
                React.createElement(PeoplePicker_1.PeoplePicker, { context: peoplePickerContext, personSelectionLimit: 1, ensureUser: true, principalTypes: [PeoplePicker_1.PrincipalType.User], onChange: function (items) { return setSelectedUser(items); } }),
                React.createElement("label", null, "GL Code"),
                React.createElement("input", { value: glCode, readOnly: true }),
                React.createElement("label", null, "Cost Center"),
                React.createElement("input", { value: employee.CostCenter || "", readOnly: true }))),
        React.createElement("div", { className: "section" },
            React.createElement("h3", null, "Remarks"),
            React.createElement("div", { className: "form-row" },
                React.createElement("label", null, "Remarks"),
                React.createElement("textarea", { value: remarks, onChange: function (e) { return setRemarks(e.target.value); } }),
                React.createElement("label", null, "Project Description"),
                React.createElement("textarea", { value: projectDesc, onChange: function (e) { return setProjectDesc(e.target.value); } }))),
        React.createElement("div", { className: "section" },
            React.createElement("h3", null, "Previous Advances"),
            React.createElement("table", { className: "data-table" },
                React.createElement("thead", null,
                    React.createElement("tr", null,
                        React.createElement("th", null, "PO Number"),
                        React.createElement("th", null, "Previous Advance"),
                        React.createElement("th", null, "Requested Date"),
                        React.createElement("th", null, "Paid Date"),
                        React.createElement("th", null, "MRN No"),
                        React.createElement("th", null, "Settled Amount"),
                        React.createElement("th", null, "Pending Advance"))),
                React.createElement("tbody", null, previousAdvances.length === 0 ? (React.createElement("tr", null,
                    React.createElement("td", { colSpan: 7, style: { textAlign: "center" } }, "No Data"))) : (previousAdvances.map(function (item, index) {
                    var pending = Math.max(0, Number(item.RequestAdvanceAmount || 0) -
                        Number(item.PaidAmount || 0));
                    return (React.createElement("tr", { key: index },
                        React.createElement("td", null, item.PONumber),
                        React.createElement("td", null, item.RequestAdvanceAmount),
                        React.createElement("td", null, item.Created
                            ? new Date(item.Created).toLocaleDateString()
                            : ""),
                        React.createElement("td", null, item.VoucherDate
                            ? new Date(item.VoucherDate).toLocaleDateString()
                            : ""),
                        React.createElement("td", null, item.VoucherNumber),
                        React.createElement("td", null, item.PaidAmount),
                        React.createElement("td", null, pending)));
                }))))),
        React.createElement("div", { className: "col-md-4" },
            React.createElement("label", { className: "font" }, "Attach"),
            React.createElement("input", { type: "file", multiple: true, onChange: function (e) {
                    var files = e.target.files;
                    if (!files)
                        return;
                    setSelectedFiles(function (prev) { return tslib_1.__spreadArray(tslib_1.__spreadArray([], prev, true), Array.from(files), true); });
                } }),
            selectedFiles.length > 0 && (React.createElement("ul", { style: { marginTop: "10px" } }, selectedFiles.map(function (file, index) { return (React.createElement("li", { key: index },
                file.name,
                React.createElement("button", { type: "button", style: {
                        marginLeft: "10px",
                        color: "red",
                        cursor: "pointer",
                    }, onClick: function () { return handleRemoveFile(index); } }, "Remove"))); })))),
        React.createElement("div", { className: "actions" },
            React.createElement("button", { className: "primary", onClick: handleSubmit }, "Submit"),
            React.createElement("button", { className: "secondary", onClick: handledraft }, "Save Draft"),
            React.createElement("button", { className: "exit", onClick: handleExit }, "Exit"))));
};
exports.default = NewAdvanceform;
//# sourceMappingURL=NewAdvanceform.js.map