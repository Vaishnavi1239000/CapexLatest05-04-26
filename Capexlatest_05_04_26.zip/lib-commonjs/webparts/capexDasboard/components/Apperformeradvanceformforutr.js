"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var tslib_1 = require("tslib");
var React = tslib_1.__importStar(require("react"));
require("./advanced.scss");
var sp_1 = require("@pnp/sp");
var all_1 = require("@pnp/sp/presets/all");
var PeoplePicker_1 = require("@pnp/spfx-controls-react/lib/PeoplePicker");
var react_1 = require("react");
var APperformerAdvanceFormForUTR = function (_a) {
    var _b;
    var context = _a.context, itemId = _a.itemId;
    var sp = (0, sp_1.spfi)().using((0, all_1.SPFx)(context));
    var _c = (0, react_1.useState)([]), attachments = _c[0], setAttachments = _c[1];
    var _d = (0, react_1.useState)(null), itemData = _d[0], setItemData = _d[1];
    var _e = (0, react_1.useState)(""), approverRemarks = _e[0], setApproverRemarks = _e[1];
    var _f = (0, react_1.useState)(""), voucherDate = _f[0], setVoucherDate = _f[1];
    var _g = (0, react_1.useState)(""), selectedVendorName = _g[0], setSelectedVendorName = _g[1];
    var _h = (0, react_1.useState)([]), vendors = _h[0], setVendors = _h[1];
    var _j = (0, react_1.useState)(null), selectedVendorId = _j[0], setSelectedVendorId = _j[1];
    var _k = (0, react_1.useState)(""), voucherNumber = _k[0], setVoucherNumber = _k[1];
    var _l = (0, react_1.useState)(""), UTRDate = _l[0], setUTRDate = _l[1];
    var _m = (0, react_1.useState)(""), UTRNumber = _m[0], setUTRNumber = _m[1];
    var _o = (0, react_1.useState)(""), UTRRemarks = _o[0], setUTRRemarks = _o[1];
    var _p = (0, react_1.useState)([]), approvalMatrix = _p[0], setApprovalMatrix = _p[1];
    var _q = (0, react_1.useState)([]), workflowHistory = _q[0], setWorkflowHistory = _q[1];
    // ✅ Fetch Item by ID
    var peoplePickerContext = {
        absoluteUrl: context.pageContext.web.absoluteUrl,
        msGraphClientFactory: context.msGraphClientFactory,
        spHttpClient: context.spHttpClient,
    };
    var getAttachments = function (capexId) { return tslib_1.__awaiter(void 0, void 0, void 0, function () {
        var safe, path, files, _a;
        return tslib_1.__generator(this, function (_b) {
            switch (_b.label) {
                case 0:
                    _b.trys.push([0, 2, , 3]);
                    safe = capexId.replace(/\//g, "_");
                    path = "/sites/SonaFinance/CapexAdvanceDocs/".concat(safe);
                    return [4 /*yield*/, sp.web.getFolderByServerRelativePath(path).files()];
                case 1:
                    files = _b.sent();
                    void setAttachments(files);
                    return [3 /*break*/, 3];
                case 2:
                    _a = _b.sent();
                    void setAttachments([]);
                    return [3 /*break*/, 3];
                case 3: return [2 /*return*/];
            }
        });
    }); };
    var getVendors = function () { return tslib_1.__awaiter(void 0, void 0, void 0, function () {
        var data, error_1;
        return tslib_1.__generator(this, function (_a) {
            switch (_a.label) {
                case 0:
                    _a.trys.push([0, 2, , 3]);
                    return [4 /*yield*/, sp.web.lists
                            .getByTitle("VendorMaster")
                            .items.select("Id", "VendorCode", "VendorName")()];
                case 1:
                    data = _a.sent();
                    setVendors(data);
                    return [3 /*break*/, 3];
                case 2:
                    error_1 = _a.sent();
                    console.error("Vendor fetch error:", error_1);
                    return [3 /*break*/, 3];
                case 3: return [2 /*return*/];
            }
        });
    }); };
    // ✅ Fetch Item by ID
    var getItemById = function () { return tslib_1.__awaiter(void 0, void 0, void 0, function () {
        var item, parsed, parsed, error_2;
        var _a;
        return tslib_1.__generator(this, function (_b) {
            switch (_b.label) {
                case 0:
                    _b.trys.push([0, 4, , 5]);
                    return [4 /*yield*/, sp.web.lists
                            .getByTitle("CapexAdvance")
                            .items.getById(itemId)
                            .select("*", "PICName/Title", "VendorCode/Id", "VendorCode/VendorCode")
                            .expand("PICName", "VendorCode")()];
                case 1:
                    item = _b.sent();
                    setItemData(item);
                    //setApproverRemarks(item.ApproverRemarks || "");
                    // ✅ FIX: Set VendorId + Name
                    setSelectedVendorId(((_a = item.VendorCode) === null || _a === void 0 ? void 0 : _a.Id) || null);
                    // 🔥 IMPORTANT
                    setSelectedVendorName(item.VendorName); // optional
                    if (!item.CapexID) return [3 /*break*/, 3];
                    return [4 /*yield*/, getAttachments(item.CapexID)];
                case 2:
                    _b.sent();
                    _b.label = 3;
                case 3:
                    // ✅ Approval Matrix
                    if (item.ApprovalMatrix) {
                        try {
                            parsed = typeof item.ApprovalMatrix === "string"
                                ? JSON.parse(item.ApprovalMatrix)
                                : item.ApprovalMatrix;
                            setApprovalMatrix(Array.isArray(parsed) ? parsed : []);
                        }
                        catch (e) {
                            console.error("ApprovalMatrix parse error", e);
                            setApprovalMatrix([]);
                        }
                    }
                    else {
                        setApprovalMatrix([]);
                    }
                    // ✅ Workflow History
                    if (item.WorkFlowHistory) {
                        try {
                            parsed = typeof item.WorkFlowHistory === "string"
                                ? JSON.parse(item.WorkFlowHistory)
                                : item.WorkFlowHistory;
                            setWorkflowHistory(Array.isArray(parsed) ? parsed : []);
                        }
                        catch (e) {
                            console.error("WorkFlowHistory parse error", e);
                            setWorkflowHistory([]);
                        }
                    }
                    else {
                        setWorkflowHistory([]);
                    }
                    return [3 /*break*/, 5];
                case 4:
                    error_2 = _b.sent();
                    console.error("Fetch error:", error_2);
                    return [3 /*break*/, 5];
                case 5: return [2 /*return*/];
            }
        });
    }); };
    (0, react_1.useEffect)(function () {
        if (!context || !itemId)
            return;
        var loadData = function () { return tslib_1.__awaiter(void 0, void 0, void 0, function () {
            return tslib_1.__generator(this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, getItemById()];
                    case 1:
                        _a.sent(); // 👈 FIRST load item to get VendorCode
                        return [4 /*yield*/, getVendors()];
                    case 2:
                        _a.sent(); // 👈 FIRST load vendors
                        return [4 /*yield*/, getItemById()];
                    case 3:
                        _a.sent(); // 👈 THEN item
                        return [2 /*return*/];
                }
            });
        }); };
        void loadData();
    }, [context, itemId]);
    // ✅ Approve
    var handleApprove = function () { return tslib_1.__awaiter(void 0, void 0, void 0, function () {
        var flow, currentUserId_1, currentIndex, history_1, error_3;
        return tslib_1.__generator(this, function (_a) {
            switch (_a.label) {
                case 0:
                    _a.trys.push([0, 2, , 3]);
                    if (!UTRDate || !UTRNumber || !UTRRemarks) {
                        alert("All fields required");
                        return [2 /*return*/];
                    }
                    flow = itemData.ApprovalMatrix
                        ? JSON.parse(itemData.ApprovalMatrix)
                        : [];
                    currentUserId_1 = context.pageContext.legacyPageContext.userId;
                    currentIndex = flow.findIndex(function (a) { return a.Id === currentUserId_1; });
                    if (currentIndex !== -1) {
                        flow[currentIndex].Status = "Approved";
                    }
                    history_1 = itemData.WorkFlowHistory
                        ? JSON.parse(itemData.WorkFlowHistory)
                        : [];
                    history_1.push({
                        CurrentApprover: context.pageContext.user.displayName,
                        ActionTaken: "Paid",
                        Comment: UTRRemarks,
                        Date: new Date().toISOString()
                    });
                    return [4 /*yield*/, sp.web.lists
                            .getByTitle("CapexAdvance")
                            .items.getById(itemId)
                            .update({
                            ApproverRemarks: approverRemarks,
                            UTRDate: new Date(UTRDate),
                            UTRNumber: UTRNumber,
                            UTRRemarks: UTRRemarks,
                            Status: "Paid",
                            ApprovalMatrix: JSON.stringify(flow),
                            WorkFlowHistory: JSON.stringify(history_1),
                            CurrentApproverId: null // 🔥 final stage
                        })];
                case 1:
                    _a.sent();
                    alert("Paid ✅");
                    window.location.href =
                        "https://isriglobal.sharepoint.com/sites/SonaFinance/SitePages/CapexForm.aspx?page=Performer";
                    return [3 /*break*/, 3];
                case 2:
                    error_3 = _a.sent();
                    console.error(error_3);
                    return [3 /*break*/, 3];
                case 3: return [2 /*return*/];
            }
        });
    }); };
    // ✅ Sent Back
    var handleSendBack = function () { return tslib_1.__awaiter(void 0, void 0, void 0, function () {
        var flow, currentUserId_2, currentIndex, history_2, error_4;
        return tslib_1.__generator(this, function (_a) {
            switch (_a.label) {
                case 0:
                    _a.trys.push([0, 2, , 3]);
                    if (!UTRRemarks) {
                        alert("Enter remarks");
                        return [2 /*return*/];
                    }
                    flow = itemData.ApprovalMatrix
                        ? JSON.parse(itemData.ApprovalMatrix)
                        : [];
                    currentUserId_2 = context.pageContext.legacyPageContext.userId;
                    currentIndex = flow.findIndex(function (a) { return a.Id === currentUserId_2; });
                    if (currentIndex !== -1) {
                        flow[currentIndex].Status = "Send Back";
                    }
                    history_2 = itemData.WorkFlowHistory
                        ? JSON.parse(itemData.WorkFlowHistory)
                        : [];
                    history_2.push({
                        CurrentApprover: context.pageContext.user.displayName,
                        ActionTaken: "Send Back",
                        Comment: UTRRemarks,
                        Date: new Date().toISOString()
                    });
                    return [4 /*yield*/, sp.web.lists
                            .getByTitle("CapexAdvance")
                            .items.getById(itemId)
                            .update({
                            ApproverRemarks: approverRemarks,
                            Status: "Send Back",
                            ApprovalMatrix: JSON.stringify(flow),
                            WorkFlowHistory: JSON.stringify(history_2),
                            CurrentApproverId: itemData.CurrentApproverId
                        })];
                case 1:
                    _a.sent();
                    alert("Send Back ✅");
                    window.location.href =
                        "https://isriglobal.sharepoint.com/sites/SonaFinance/SitePages/CapexForm.aspx?page=Performer";
                    return [3 /*break*/, 3];
                case 2:
                    error_4 = _a.sent();
                    console.error(error_4);
                    return [3 /*break*/, 3];
                case 3: return [2 /*return*/];
            }
        });
    }); };
    // ✅ Reject
    var handleReject = function () { return tslib_1.__awaiter(void 0, void 0, void 0, function () {
        var flow, currentUserId_3, currentIndex, history_3, error_5;
        return tslib_1.__generator(this, function (_a) {
            switch (_a.label) {
                case 0:
                    _a.trys.push([0, 2, , 3]);
                    if (!UTRRemarks) {
                        alert("Enter remarks");
                        return [2 /*return*/];
                    }
                    flow = itemData.ApprovalMatrix
                        ? JSON.parse(itemData.ApprovalMatrix)
                        : [];
                    currentUserId_3 = context.pageContext.legacyPageContext.userId;
                    currentIndex = flow.findIndex(function (a) { return a.Id === currentUserId_3; });
                    if (currentIndex !== -1) {
                        flow[currentIndex].Status = "Rejected";
                    }
                    history_3 = itemData.WorkFlowHistory
                        ? JSON.parse(itemData.WorkFlowHistory)
                        : [];
                    history_3.push({
                        CurrentApprover: context.pageContext.user.displayName,
                        ActionTaken: "Rejected",
                        Comment: UTRRemarks,
                        Date: new Date().toISOString()
                    });
                    return [4 /*yield*/, sp.web.lists
                            .getByTitle("CapexAdvance")
                            .items.getById(itemId)
                            .update({
                            ApproverRemarks: approverRemarks,
                            Status: "Rejected",
                            ApprovalMatrix: JSON.stringify(flow),
                            WorkFlowHistory: JSON.stringify(history_3),
                            CurrentApproverId: null
                        })];
                case 1:
                    _a.sent();
                    alert("Rejected ❌");
                    window.location.href =
                        "https://isriglobal.sharepoint.com/sites/SonaFinance/SitePages/CapexForm.aspx?page=Performer";
                    return [3 /*break*/, 3];
                case 2:
                    error_5 = _a.sent();
                    console.error(error_5);
                    return [3 /*break*/, 3];
                case 3: return [2 /*return*/];
            }
        });
    }); };
    var handleExit = function () {
        window.location.href = "https://isriglobal.sharepoint.com/sites/SonaFinance/SitePages/CapexForm.aspx?page=Performer";
    };
    // ⛔ Wait until data loads
    if (!itemData)
        return React.createElement("div", null, "Loading...");
    return (React.createElement("div", { className: "form-container" },
        React.createElement("h2", { className: "form-title" }, "Advance Payment (Approver)"),
        React.createElement("div", { className: "section" },
            React.createElement("h3", null, "Approval Matrix"),
            approvalMatrix.length === 0 ? (React.createElement("p", null, "No approval data")) : (React.createElement("div", { className: "approval-flow" }, approvalMatrix.map(function (a, index) { return (React.createElement("div", { key: index, className: "approval-step ".concat(a.Status === "In Progress"
                    ? "active"
                    : a.Status === "Approved"
                        ? "approved"
                        : "") },
                React.createElement("div", null,
                    React.createElement("b", null, a.Role)),
                React.createElement("div", null, a.Name),
                React.createElement("div", { className: "status" }, a.Status))); })))),
        React.createElement("div", { className: "section" },
            React.createElement("h3", null, "Requestor Information"),
            React.createElement("div", { className: "form-row" },
                React.createElement("label", null, "Employee Code"),
                React.createElement("input", { value: itemData.EmployeeCode || "", readOnly: true }),
                React.createElement("label", null, "Employee Name"),
                React.createElement("input", { value: itemData.EmployeeName || "", readOnly: true }),
                React.createElement("label", null, "Division"),
                React.createElement("input", { value: itemData.Division || "", readOnly: true }),
                React.createElement("label", null, "Location"),
                React.createElement("input", { value: itemData.Location || "", readOnly: true })),
            React.createElement("div", { className: "form-row" },
                React.createElement("label", null, "Email"),
                React.createElement("input", { value: itemData.Email || "", readOnly: true }),
                React.createElement("label", null, "RM"),
                React.createElement("input", { value: itemData.RM || "", readOnly: true }),
                React.createElement("label", null, "HOD"),
                React.createElement("input", { value: itemData.HOD || "", readOnly: true }),
                React.createElement("label", null, "Contact No"),
                React.createElement("input", { value: itemData.ContactNo || "", readOnly: true }))),
        React.createElement("div", { className: "section" },
            React.createElement("h3", null, "Vendor & PO Details"),
            React.createElement("div", { className: "form-row" },
                React.createElement("label", null, "Vendor Code"),
                React.createElement("select", { value: selectedVendorId !== null && selectedVendorId !== void 0 ? selectedVendorId : "", disabled: true, onChange: function (e) {
                        var id = Number(e.target.value);
                        var vendor = vendors.find(function (v) { return v.Id === id; });
                        setSelectedVendorId(id);
                        setSelectedVendorName((vendor === null || vendor === void 0 ? void 0 : vendor.VendorName) || "");
                    } },
                    React.createElement("option", { value: "" }, "Select Vendor"),
                    vendors.map(function (v) { return (React.createElement("option", { key: v.Id, value: v.Id }, v.VendorCode)); })),
                React.createElement("label", null, "Vendor Name"),
                React.createElement("input", { value: itemData.VendorName || "", readOnly: true }),
                React.createElement("label", null, "PO Number"),
                React.createElement("input", { value: itemData.PONumber || "", readOnly: true }),
                React.createElement("label", null, "PO Date"),
                React.createElement("input", { value: itemData.PODate
                        ? new Date(itemData.PODate).toLocaleDateString("en-GB")
                        : "", readOnly: true })),
            React.createElement("div", { className: "form-row" },
                React.createElement("label", null, "PO Terms"),
                React.createElement("input", { value: itemData.POAdvanceTerms || "", readOnly: true }),
                React.createElement("label", null, "PO Amount"),
                React.createElement("input", { value: itemData.POAmtGST || "", readOnly: true }),
                React.createElement("label", null, "Advance Amount"),
                React.createElement("input", { value: itemData.RequestAdvanceAmount || "", readOnly: true }),
                React.createElement("label", null, "Paid Amount"),
                React.createElement("input", { value: itemData.PaidAmount || "", readOnly: true }))),
        React.createElement("div", { className: "section" },
            React.createElement("h3", null, "Advance Details"),
            React.createElement("div", { className: "form-row" },
                React.createElement("label", null, "Expected Settlement"),
                React.createElement("input", { value: itemData.ExpectedDateofSettlement
                        ? new Date(itemData.ExpectedDateofSettlement).toLocaleDateString("en-GB")
                        : "", readOnly: true }),
                React.createElement("label", null, "PIC Name"),
                React.createElement(PeoplePicker_1.PeoplePicker, { context: peoplePickerContext, personSelectionLimit: 1, disabled: true, principalTypes: [PeoplePicker_1.PrincipalType.User], defaultSelectedUsers: ((_b = itemData === null || itemData === void 0 ? void 0 : itemData.PICName) === null || _b === void 0 ? void 0 : _b.Title) ? [itemData.PICName.Title] : [] }),
                React.createElement("label", null, "GL Code"),
                React.createElement("input", { value: itemData.GL || "", readOnly: true }),
                React.createElement("label", null, "Cost Center"),
                React.createElement("input", { value: itemData.CostCenter || "", readOnly: true }))),
        React.createElement("div", { className: "section" },
            React.createElement("h3", null, "Remarks"),
            React.createElement("div", { className: "form-row" },
                React.createElement("label", null, "User Remarks"),
                React.createElement("textarea", { value: itemData.Remarks || "", readOnly: true }),
                React.createElement("label", null, "Project Description"),
                React.createElement("textarea", { value: itemData.ProjectDescription || "", readOnly: true }))),
        React.createElement("div", { className: "section" },
            React.createElement("h3", null, "Workflow History"),
            workflowHistory.length === 0 ? (React.createElement("p", null, "No history available")) : (React.createElement("div", { className: "workflow-history" }, workflowHistory.map(function (h, index) { return (React.createElement("div", { key: index, className: "history-item" },
                React.createElement("div", null,
                    h.ActionTaken === "Approved" && "✅ ",
                    h.ActionTaken === "Rejected" && "❌ ",
                    h.ActionTaken === "Send Back" && "↩ ",
                    h.ActionTaken),
                React.createElement("div", null,
                    React.createElement("b", null, h.CurrentApprover)),
                React.createElement("div", null, h.Comment),
                React.createElement("div", { className: "date" }, new Date(h.Date).toLocaleString()))); })))),
        React.createElement("div", { className: "section" },
            React.createElement("h3", null, "Approver Action"),
            React.createElement("label", null, "Approver Remarks"),
            React.createElement("textarea", { value: approverRemarks, onChange: function (e) { return setApproverRemarks(e.target.value); }, readOnly: true })),
        React.createElement("label", null, "Voucher Date"),
        React.createElement("input", { value: itemData.VoucherDate
                ? new Date(itemData.VoucherDate).toLocaleDateString("en-GB")
                : "", readOnly: true }),
        React.createElement("label", null, "Voucher Number"),
        React.createElement("input", { value: itemData.VouchingNumber || "", readOnly: true }),
        React.createElement("div", { className: "section" },
            React.createElement("div", { className: "section" },
                React.createElement("h3", null, "Attachments"),
                attachments.length === 0 ? (React.createElement("p", null, "No attachments")) : (React.createElement("ul", null, attachments.map(function (file, index) { return (React.createElement("li", { key: index },
                    React.createElement("a", { href: file.ServerRelativeUrl, target: "_blank", rel: "noopener noreferrer" }, file.Name))); }))))),
        React.createElement("label", null, "UTR Date"),
        React.createElement("input", { type: "date", value: UTRDate, onChange: function (e) { return setUTRDate(e.target.value); } }),
        React.createElement("label", null, "UTR Number"),
        React.createElement("input", { value: UTRNumber, onChange: function (e) { return setUTRNumber(e.target.value); } }),
        React.createElement("label", null, "UTR Remarks"),
        React.createElement("input", { onChange: function (e) { return setUTRRemarks(e.target.value); } }),
        React.createElement("div", { className: "actions" },
            React.createElement("button", { className: "primary", onClick: handleApprove }, "Paid"),
            React.createElement("button", { className: "secondary", onClick: handleSendBack }, "Sent Back"),
            React.createElement("button", { className: "secondary", onClick: handleReject }, "Reject"),
            React.createElement("button", { className: "exit", onClick: handleExit }, "Exit"))));
};
exports.default = APperformerAdvanceFormForUTR;
//# sourceMappingURL=APperformerAdvanceFormForUTR.js.map