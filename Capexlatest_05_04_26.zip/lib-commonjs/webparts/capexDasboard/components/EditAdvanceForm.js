"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var tslib_1 = require("tslib");
var React = tslib_1.__importStar(require("react"));
require("./advanced.scss");
var sp_1 = require("@pnp/sp");
var all_1 = require("@pnp/sp/presets/all");
var react_1 = require("react");
var PeoplePicker_1 = require("@pnp/spfx-controls-react/lib/PeoplePicker");
var EditAdvanceForm = function (_a) {
    var _b, _c;
    var context = _a.context, formData = _a.formData, onClose = _a.onClose;
    var sp = (0, sp_1.spfi)().using((0, all_1.SPFx)(context));
    // =========================
    // STATES
    // =========================
    var _d = (0, react_1.useState)([]), vendors = _d[0], setVendors = _d[1];
    var _e = (0, react_1.useState)({}), employee = _e[0], setEmployee = _e[1];
    var _f = (0, react_1.useState)([]), attachments = _f[0], setAttachments = _f[1];
    var _g = (0, react_1.useState)([]), selectedFiles = _g[0], setSelectedFiles = _g[1];
    var _h = (0, react_1.useState)([]), selectedUser = _h[0], setSelectedUser = _h[1];
    var _j = (0, react_1.useState)(null), selectedVendorId = _j[0], setSelectedVendorId = _j[1];
    var _k = (0, react_1.useState)(""), selectedVendorName = _k[0], setSelectedVendorName = _k[1];
    var _l = (0, react_1.useState)(""), poNumber = _l[0], setPoNumber = _l[1];
    var _m = (0, react_1.useState)(""), poDate = _m[0], setPoDate = _m[1];
    var _o = (0, react_1.useState)(""), poTerms = _o[0], setPoTerms = _o[1];
    var _p = (0, react_1.useState)(""), poAmount = _p[0], setPoAmount = _p[1];
    var _q = (0, react_1.useState)(""), advanceAmount = _q[0], setAdvanceAmount = _q[1];
    var _r = (0, react_1.useState)(""), paidAmount = _r[0], setPaidAmount = _r[1];
    var _s = (0, react_1.useState)(""), expectedDate = _s[0], setExpectedDate = _s[1];
    var _t = (0, react_1.useState)(""), vendorName = _t[0], setVendorName = _t[1];
    var _u = (0, react_1.useState)("390111003"), glCode = _u[0], setGlCode = _u[1];
    var _v = (0, react_1.useState)(""), costCenter = _v[0], setCostCenter = _v[1];
    var _w = (0, react_1.useState)(""), remarks = _w[0], setRemarks = _w[1];
    var _x = (0, react_1.useState)(""), projectDesc = _x[0], setProjectDesc = _x[1];
    var _y = (0, react_1.useState)(""), approverRemarks = _y[0], setApproverRemarks = _y[1];
    var _z = (0, react_1.useState)(""), voucherDate = _z[0], setVoucherDate = _z[1];
    var _0 = (0, react_1.useState)(""), voucherNumber = _0[0], setVoucherNumber = _0[1];
    var _1 = (0, react_1.useState)(""), UTRDate = _1[0], setUTRDate = _1[1];
    var _2 = (0, react_1.useState)(""), UTRNumber = _2[0], setUTRNumber = _2[1];
    var _3 = (0, react_1.useState)([]), approvalMatrix = _3[0], setApprovalMatrix = _3[1];
    var _4 = (0, react_1.useState)([]), workflowHistory = _4[0], setWorkflowHistory = _4[1];
    var _5 = (0, react_1.useState)([]), previousAdvances = _5[0], setPreviousAdvances = _5[1];
    var peoplePickerContext = {
        absoluteUrl: context.pageContext.web.absoluteUrl,
        msGraphClientFactory: context.msGraphClientFactory,
        spHttpClient: context.spHttpClient,
    };
    // =========================
    // LOAD DATA
    // =========================
    var handleDeleteExistingFile = function (file) { return tslib_1.__awaiter(void 0, void 0, void 0, function () {
        var error_1;
        return tslib_1.__generator(this, function (_a) {
            switch (_a.label) {
                case 0:
                    _a.trys.push([0, 2, , 3]);
                    if (!window.confirm("Delete ".concat(file.Name, "?")))
                        return [2 /*return*/];
                    return [4 /*yield*/, sp.web.getFileByServerRelativePath(file.ServerRelativeUrl).delete()];
                case 1:
                    _a.sent();
                    // update UI
                    setAttachments(function (prev) {
                        return prev.filter(function (f) { return f.ServerRelativeUrl !== file.ServerRelativeUrl; });
                    });
                    alert("File deleted ✅");
                    return [3 /*break*/, 3];
                case 2:
                    error_1 = _a.sent();
                    console.error("Delete error:", error_1);
                    return [3 /*break*/, 3];
                case 3: return [2 /*return*/];
            }
        });
    }); };
    var handleNumberChange = function (value, setter) {
        // Allow only numbers and decimal (max one dot)
        var regex = /^\d*\.?\d*$/;
        if (regex.test(value)) {
            void setter(value);
        }
    };
    var getPreviousAdvances = function (vendorId) { return tslib_1.__awaiter(void 0, void 0, void 0, function () {
        var data, error_2;
        return tslib_1.__generator(this, function (_a) {
            switch (_a.label) {
                case 0:
                    _a.trys.push([0, 2, , 3]);
                    debugger;
                    console.log("Fetching for Vendor:", vendorId);
                    return [4 /*yield*/, sp.web.lists
                            .getByTitle("CapexAdvance")
                            .items.select("PONumber", "RequestAdvanceAmount", "Created", "VoucherDate", "PaidAmount", "Status", "VendorCode/Id")
                            .expand("VendorCode")
                            .filter("VendorCode/Id eq ".concat(vendorId, " and Status eq 'Paid'"))
                            .orderBy("Created", false)()];
                case 1:
                    data = _a.sent();
                    console.log("DATA:", data);
                    void setPreviousAdvances(data);
                    return [3 /*break*/, 3];
                case 2:
                    error_2 = _a.sent();
                    console.error("Error fetching previous advances:", error_2);
                    void setPreviousAdvances([]);
                    return [3 /*break*/, 3];
                case 3: return [2 /*return*/];
            }
        });
    }); };
    var getVendors = function () { return tslib_1.__awaiter(void 0, void 0, void 0, function () {
        var data;
        return tslib_1.__generator(this, function (_a) {
            switch (_a.label) {
                case 0: return [4 /*yield*/, sp.web.lists
                        .getByTitle("VendorMaster")
                        .items.select("Id", "VendorCode", "VendorName")()];
                case 1:
                    data = _a.sent();
                    void setVendors(data);
                    return [2 /*return*/];
            }
        });
    }); };
    var getLoggedInUser = function () { return tslib_1.__awaiter(void 0, void 0, void 0, function () {
        var currentUser, email, user, error_3;
        return tslib_1.__generator(this, function (_a) {
            switch (_a.label) {
                case 0:
                    _a.trys.push([0, 3, , 4]);
                    return [4 /*yield*/, sp.web.currentUser()];
                case 1:
                    currentUser = _a.sent();
                    email = currentUser.Email;
                    return [4 /*yield*/, sp.web.lists
                            .getByTitle("EmployeeMaster")
                            .items.select("EmployeeCode", "EmployeeName", "Division", "Location", "EmployeeEmail", "ReportingManager/Title", "HOD/Title", "ContactNo", "EmployeeStatus", "CostCenter")
                            .expand("ReportingManager", "HOD")
                            .filter("EmployeeEmail eq '".concat(email, "'"))
                            .top(1)()];
                case 2:
                    user = _a.sent();
                    if (user.length > 0) {
                        setEmployee(user[0]);
                    }
                    return [3 /*break*/, 4];
                case 3:
                    error_3 = _a.sent();
                    console.log("Error fetching user:", error_3);
                    return [3 /*break*/, 4];
                case 4: return [2 /*return*/];
            }
        });
    }); };
    var getAttachments = function (capexId) { return tslib_1.__awaiter(void 0, void 0, void 0, function () {
        var safe, path, files, _a;
        return tslib_1.__generator(this, function (_b) {
            switch (_b.label) {
                case 0:
                    _b.trys.push([0, 2, , 3]);
                    safe = capexId.replace(/\//g, "_");
                    path = "/sites/SonaFinance/CapexAdvanceDocs/".concat(safe);
                    return [4 /*yield*/, sp.web
                            .getFolderByServerRelativePath(path)
                            .files()];
                case 1:
                    files = _b.sent();
                    void setAttachments(files);
                    return [3 /*break*/, 3];
                case 2:
                    _a = _b.sent();
                    void setAttachments([]);
                    return [3 /*break*/, 3];
                case 3: return [2 /*return*/];
            }
        });
    }); };
    // =========================
    // UPLOAD FILES
    // =========================
    // =========================
    // VALIDATION
    // =========================
    var validateForm = function () {
        var errors = [];
        if (!selectedVendorId) {
            errors.push("Please select the Vendor code");
        }
        if (!poNumber) {
            errors.push("Please update PO Number");
        }
        if (!poDate) {
            errors.push("Please update PO date");
        }
        if (!poTerms) {
            errors.push("Please update PO Terms");
        }
        if (!poAmount) {
            errors.push("Please update PO Amount");
        }
        if (!advanceAmount || Number(advanceAmount) <= 0) {
            errors.push("Please update Advance Amount");
        }
        if (!paidAmount || Number(paidAmount) <= 0) {
            errors.push("Please update Paid Amount");
        }
        // 🔥 NEW VALIDATION
        if (advanceAmount &&
            paidAmount &&
            Number(paidAmount) > Number(advanceAmount)) {
            errors.push("Paid Amount cannot be greater than Advance Amount");
        }
        if (!expectedDate) {
            errors.push("Please update Settlement Date");
        }
        if (!selectedUser || selectedUser.length === 0) {
            errors.push("Please select PIC Name");
        }
        if (!projectDesc) {
            errors.push("Please enter Project Description");
        }
        if ((!attachments || attachments.length === 0) &&
            (!selectedFiles || selectedFiles.length === 0)) {
            errors.push("Please upload at least one attachment");
        }
        return errors;
    };
    var handleExit = function () {
        if (onClose) {
            onClose();
        }
        else {
            window.location.reload();
        }
    };
    var ensureFolder = function (folderPath) { return tslib_1.__awaiter(void 0, void 0, void 0, function () {
        var _a, parentPath, folderName;
        return tslib_1.__generator(this, function (_b) {
            switch (_b.label) {
                case 0:
                    _b.trys.push([0, 2, , 4]);
                    return [4 /*yield*/, sp.web.getFolderByServerRelativePath(folderPath)()];
                case 1:
                    _b.sent();
                    return [3 /*break*/, 4];
                case 2:
                    _a = _b.sent();
                    parentPath = folderPath.substring(0, folderPath.lastIndexOf("/"));
                    folderName = folderPath.substring(folderPath.lastIndexOf("/") + 1);
                    return [4 /*yield*/, sp.web
                            .getFolderByServerRelativePath(parentPath)
                            .folders.addUsingPath(folderName)];
                case 3:
                    _b.sent();
                    return [3 /*break*/, 4];
                case 4: return [2 /*return*/];
            }
        });
    }); };
    var uploadFiles = function () { return tslib_1.__awaiter(void 0, void 0, void 0, function () {
        var safe, folderPath, _i, selectedFiles_1, file, error_4;
        return tslib_1.__generator(this, function (_a) {
            switch (_a.label) {
                case 0:
                    _a.trys.push([0, 7, , 8]);
                    if (!(formData === null || formData === void 0 ? void 0 : formData.CapexID) || selectedFiles.length === 0)
                        return [2 /*return*/];
                    safe = formData.CapexID.replace(/\//g, "_");
                    folderPath = "/sites/SonaFinance/CapexAdvanceDocs/".concat(safe);
                    // ✅ Ensure folder exists
                    return [4 /*yield*/, ensureFolder(folderPath)];
                case 1:
                    // ✅ Ensure folder exists
                    _a.sent();
                    _i = 0, selectedFiles_1 = selectedFiles;
                    _a.label = 2;
                case 2:
                    if (!(_i < selectedFiles_1.length)) return [3 /*break*/, 5];
                    file = selectedFiles_1[_i];
                    return [4 /*yield*/, sp.web
                            .getFolderByServerRelativePath(folderPath)
                            .files.addUsingPath(file.name, file, { Overwrite: true })];
                case 3:
                    _a.sent();
                    _a.label = 4;
                case 4:
                    _i++;
                    return [3 /*break*/, 2];
                case 5:
                    setSelectedFiles([]);
                    return [4 /*yield*/, getAttachments(formData.CapexID)];
                case 6:
                    _a.sent();
                    return [3 /*break*/, 8];
                case 7:
                    error_4 = _a.sent();
                    console.error("Upload error:", error_4);
                    alert("File upload failed ❌");
                    return [3 /*break*/, 8];
                case 8: return [2 /*return*/];
            }
        });
    }); };
    // =========================
    // UPDATE
    // =========================
    var handleSubmit = function () { return tslib_1.__awaiter(void 0, void 0, void 0, function () {
        var errors, ensuredUser, existingFlow, updatedFlow, currentApprover, history_1, e_1;
        var _a, _b, _c;
        return tslib_1.__generator(this, function (_d) {
            switch (_d.label) {
                case 0:
                    _d.trys.push([0, 5, , 6]);
                    errors = validateForm();
                    if (errors.length > 0) {
                        alert(errors.join("\n"));
                        return [2 /*return*/];
                    }
                    return [4 /*yield*/, sp.web.ensureUser((_a = selectedUser[0]) === null || _a === void 0 ? void 0 : _a.secondaryText)];
                case 1:
                    ensuredUser = _d.sent();
                    existingFlow = formData.ApprovalMatrix
                        ? JSON.parse(formData.ApprovalMatrix)
                        : [];
                    updatedFlow = existingFlow.map(function (a, index) { return (tslib_1.__assign(tslib_1.__assign({}, a), { Status: index === 0 ? "In Progress" : "Pending" })); });
                    currentApprover = updatedFlow.length > 0 ? updatedFlow[0].Id : null;
                    history_1 = formData.WorkFlowHistory
                        ? JSON.parse(formData.WorkFlowHistory)
                        : [];
                    history_1.push({
                        CurrentApprover: employee.EmployeeName,
                        ActionTaken: "Edited",
                        Comment: remarks,
                        Date: new Date().toISOString()
                    });
                    return [4 /*yield*/, sp.web.lists
                            .getByTitle("CapexAdvance")
                            .items.getById(formData.ID)
                            .update({
                            Title: formData.CapexID,
                            CapexID: formData.CapexID,
                            EmployeeCode: employee.EmployeeCode,
                            EmployeeName: employee.EmployeeName,
                            Division: employee.Division,
                            Location: employee.Location,
                            Email: employee.EmployeeEmail,
                            RM: (_b = employee.ReportingManager) === null || _b === void 0 ? void 0 : _b.Title,
                            HOD: (_c = employee.HOD) === null || _c === void 0 ? void 0 : _c.Title,
                            ContactNo: employee.ContactNo,
                            EmployeeStatus: employee.EmployeeStatus,
                            VendorCodeId: selectedVendorId,
                            VendorName: selectedVendorName,
                            PONumber: poNumber,
                            PODate: poDate ? new Date(poDate) : null,
                            POAdvanceTerms: poTerms,
                            POAmtGST: poAmount,
                            RequestAdvanceAmount: advanceAmount,
                            PaidAmount: paidAmount,
                            ExpectedDateofSettlement: expectedDate
                                ? new Date(expectedDate)
                                : null,
                            PICNameId: ensuredUser.Id,
                            GL: glCode,
                            CostCenter: costCenter,
                            Remarks: remarks,
                            ProjectDescription: projectDesc,
                            Status: "Pending for Approver",
                            // Status: formData.Status, 
                            ApprovalMatrix: JSON.stringify(updatedFlow),
                            WorkFlowHistory: JSON.stringify(history_1),
                            CurrentApproverId: currentApprover
                        })];
                case 2:
                    _d.sent();
                    if (!(selectedFiles.length > 0)) return [3 /*break*/, 4];
                    return [4 /*yield*/, uploadFiles()];
                case 3:
                    _d.sent();
                    _d.label = 4;
                case 4:
                    alert("Updated successfully ✅");
                    window.location.href =
                        "https://isriglobal.sharepoint.com/sites/SonaFinance/SitePages/CapexForm.aspx?page=User";
                    void handleExit();
                    return [3 /*break*/, 6];
                case 5:
                    e_1 = _d.sent();
                    console.error(e_1);
                    alert("Error ❌");
                    return [3 /*break*/, 6];
                case 6: return [2 /*return*/];
            }
        });
    }); };
    // =========================
    // BIND DATA
    // =========================
    (0, react_1.useEffect)(function () {
        var _a, _b, _c, _d, _e;
        if (!formData)
            return;
        setPoNumber(formData.PONumber || "");
        setPoDate(((_a = formData.PODate) === null || _a === void 0 ? void 0 : _a.split("T")[0]) || "");
        setPoTerms(formData.POAdvanceTerms || "");
        setPoAmount(formData.POAmtGST || "");
        setAdvanceAmount(formData.RequestAdvanceAmount || "");
        setPaidAmount(formData.PaidAmount || "");
        setExpectedDate(((_b = formData.ExpectedDateofSettlement) === null || _b === void 0 ? void 0 : _b.split("T")[0]) || "");
        setVendorName(formData.VendorName || "");
        setSelectedVendorId(formData.VendorCodeId || null); // ✅ ADD THIS
        void getPreviousAdvances(formData.VendorCodeId || null);
        setSelectedVendorName(formData.VendorName || ""); // ✅ ADD THIS
        setGlCode(formData.GL || "");
        setCostCenter(formData.CostCenter || "");
        setRemarks(formData.Remarks || "");
        setProjectDesc(formData.ProjectDescription || "");
        setApproverRemarks(formData.ApproverRemarks || "");
        setVoucherDate(((_c = formData.VoucherDate) === null || _c === void 0 ? void 0 : _c.split("T")[0]) || "");
        setVoucherNumber(formData.VoucherNumber || "");
        setUTRDate(((_d = formData.UTRDate) === null || _d === void 0 ? void 0 : _d.split("T")[0]) || "");
        setUTRNumber(formData.UTRNumber || "");
        // ✅ PIC FIX
        if ((_e = formData === null || formData === void 0 ? void 0 : formData.PICName) === null || _e === void 0 ? void 0 : _e.Title) {
            setSelectedUser([
                {
                    text: formData.PICName.Title,
                    secondaryText: formData.PICName.EMail,
                },
            ]);
        }
        // ✅ Approval Matrix
        if (formData === null || formData === void 0 ? void 0 : formData.ApprovalMatrix) {
            try {
                var parsed = typeof formData.ApprovalMatrix === "string"
                    ? JSON.parse(formData.ApprovalMatrix)
                    : formData.ApprovalMatrix;
                setApprovalMatrix(Array.isArray(parsed) ? parsed : []);
            }
            catch (e) {
                console.error("ApprovalMatrix parse error", e);
                setApprovalMatrix([]);
            }
        }
        // ✅ Workflow History
        if (formData === null || formData === void 0 ? void 0 : formData.WorkFlowHistory) {
            try {
                var parsed = typeof formData.WorkFlowHistory === "string"
                    ? JSON.parse(formData.WorkFlowHistory)
                    : formData.WorkFlowHistory;
                setWorkflowHistory(Array.isArray(parsed) ? parsed : []);
            }
            catch (e) {
                console.error("WorkFlowHistory parse error", e);
                setWorkflowHistory([]);
            }
        }
        if (formData.CapexID) {
            void getAttachments(formData.CapexID);
        }
    }, [formData]);
    (0, react_1.useEffect)(function () {
        void getLoggedInUser();
        void getVendors();
    }, []);
    // =========================
    // UI
    // =========================
    return (React.createElement("div", { className: "form-container" },
        React.createElement("h2", { className: "form-title" }, "Edit Advance Payment"),
        React.createElement("div", { className: "section" },
            React.createElement("h3", null, "Approval Matrix"),
            approvalMatrix.length === 0 ? (React.createElement("p", null, "No approval data")) : (React.createElement("div", { className: "approval-flow" }, approvalMatrix.map(function (a, index) { return (React.createElement("div", { key: index, className: "approval-step ".concat(a.Status === "In Progress"
                    ? "active"
                    : a.Status === "Approved"
                        ? "approved"
                        : a.Status === "Rejected"
                            ? "rejected"
                            : a.Status === "Send Back"
                                ? "sendback"
                                : "") },
                React.createElement("div", null,
                    React.createElement("b", null, a.Role)),
                React.createElement("div", null, a.Name),
                React.createElement("div", null, a.Status))); })))),
        React.createElement("div", { className: "section" },
            React.createElement("h3", null, "Requestor Information"),
            React.createElement("div", { className: "form-row" },
                React.createElement("label", null, "Employee Code"),
                React.createElement("input", { value: employee.EmployeeCode || "", readOnly: true }),
                React.createElement("label", null, "Employee Name"),
                React.createElement("input", { value: employee.EmployeeName || "", readOnly: true }),
                React.createElement("label", null, "Division"),
                React.createElement("input", { value: employee.Division || "", readOnly: true }),
                React.createElement("label", null, "Location"),
                React.createElement("input", { value: employee.Location || "", readOnly: true })),
            React.createElement("div", { className: "form-row" },
                React.createElement("label", null, "Email"),
                React.createElement("input", { value: employee.EmployeeEmail || "", readOnly: true }),
                React.createElement("label", null, "RM"),
                React.createElement("input", { value: ((_b = employee.ReportingManager) === null || _b === void 0 ? void 0 : _b.Title) || "", readOnly: true }),
                React.createElement("label", null, "HOD"),
                React.createElement("input", { value: ((_c = employee.HOD) === null || _c === void 0 ? void 0 : _c.Title) || "", readOnly: true }),
                React.createElement("label", null, "Contact No"),
                React.createElement("input", { value: employee.ContactNo || "", readOnly: true })),
            React.createElement("div", { className: "form-row" },
                React.createElement("label", null, "Employee Status"),
                React.createElement("input", { value: employee.EmployeeStatus || "", readOnly: true }))),
        React.createElement("div", { className: "section" },
            React.createElement("h3", null, "Vendor & PO Details"),
            React.createElement("div", { className: "form-row" },
                React.createElement("label", null, "Vendor Code"),
                React.createElement("select", { value: selectedVendorId || "", onChange: function (e) {
                        var id = Number(e.target.value);
                        var vendor = vendors.find(function (v) { return v.Id === id; });
                        setSelectedVendorId(id);
                        setSelectedVendorName((vendor === null || vendor === void 0 ? void 0 : vendor.VendorName) || "");
                        if (id) {
                            void getPreviousAdvances(id);
                        }
                    } },
                    React.createElement("option", { value: "" }, "Select Vendor"),
                    vendors.map(function (v) { return (React.createElement("option", { key: v.Id, value: v.Id }, v.VendorCode)); })),
                React.createElement("label", null, "Vendor Name"),
                React.createElement("input", { value: selectedVendorName || vendorName, readOnly: true }),
                React.createElement("label", null, "PO Number"),
                React.createElement("input", { value: poNumber, onChange: function (e) { return setPoNumber(e.target.value); } }),
                React.createElement("label", null, "PO Date"),
                React.createElement("input", { type: "date", value: poDate, onChange: function (e) { return setPoDate(e.target.value); } })),
            React.createElement("div", { className: "form-row" },
                React.createElement("label", null, "PO Advance Terms"),
                React.createElement("input", { value: poTerms, onChange: function (e) { return setPoTerms(e.target.value); } }),
                React.createElement("label", null, "PO Amount (GST)"),
                React.createElement("input", { value: poAmount, onChange: function (e) { return handleNumberChange(e.target.value, setPoAmount); } }),
                React.createElement("label", null, "Request Advance Amount"),
                React.createElement("input", { value: advanceAmount, onChange: function (e) {
                        return handleNumberChange(e.target.value, setAdvanceAmount);
                    } }),
                React.createElement("label", { style: { color: "red" } }, "Paid Amount"),
                React.createElement("input", { value: paidAmount, onChange: function (e) { return handleNumberChange(e.target.value, setPaidAmount); } }))),
        React.createElement("div", { className: "section" },
            React.createElement("h3", null, "Advance Details"),
            React.createElement("div", { className: "form-row" },
                React.createElement("label", null, "Expected Settlement Date"),
                React.createElement("input", { type: "date", value: expectedDate, onChange: function (e) { return setExpectedDate(e.target.value); } }),
                React.createElement("label", null, "PIC Name"),
                React.createElement(PeoplePicker_1.PeoplePicker, { context: peoplePickerContext, personSelectionLimit: 1, ensureUser: true, principalTypes: [PeoplePicker_1.PrincipalType.User], defaultSelectedUsers: selectedUser.length > 0
                        ? [selectedUser[0].secondaryText] // ✅ use email
                        : [], onChange: function (items) { return setSelectedUser(items); } }),
                React.createElement("label", null, "GL Code"),
                React.createElement("input", { value: glCode, readOnly: true }),
                React.createElement("label", null, "Cost Center"),
                React.createElement("input", { value: employee.CostCenter || "", readOnly: true }))),
        React.createElement("div", { className: "section" },
            React.createElement("h3", null, "Remarks"),
            React.createElement("div", { className: "form-row" },
                React.createElement("label", null, "Remarks"),
                React.createElement("textarea", { value: remarks, onChange: function (e) { return setRemarks(e.target.value); } }),
                React.createElement("label", null, "Project Description"),
                React.createElement("textarea", { value: projectDesc, onChange: function (e) { return setProjectDesc(e.target.value); } }))),
        React.createElement("div", { className: "section" },
            React.createElement("h3", null, "Previous Advances"),
            React.createElement("table", { className: "data-table" },
                React.createElement("thead", null,
                    React.createElement("tr", null,
                        React.createElement("th", null, "PO Number"),
                        React.createElement("th", null, "Previous Advance"),
                        React.createElement("th", null, "Requested Date"),
                        React.createElement("th", null, "Paid Date"),
                        React.createElement("th", null, "MRN No"),
                        React.createElement("th", null, "Settled Amount"),
                        React.createElement("th", null, "Pending Advance"))),
                React.createElement("tbody", null,
                    React.createElement("tr", null,
                        React.createElement("td", { colSpan: 7, style: { textAlign: "center" } }, "No Data"))))),
        React.createElement("div", { className: "section" },
            React.createElement("h3", null, "Workflow History"),
            workflowHistory.length === 0 ? (React.createElement("p", null, "No history available")) : (React.createElement("div", { className: "workflow-history" }, workflowHistory.map(function (h, index) { return (React.createElement("div", { key: index, className: "history-item" },
                React.createElement("div", null,
                    h.ActionTaken === "Submitted" && "📩 ",
                    h.ActionTaken === "Approved" && "✅ ",
                    h.ActionTaken === "Rejected" && "❌ ",
                    h.ActionTaken === "Send Back" && "↩ ",
                    h.ActionTaken),
                React.createElement("div", null,
                    React.createElement("b", null, h.CurrentApprover)),
                React.createElement("div", null, h.Comment),
                React.createElement("div", null, new Date(h.Date).toLocaleString()))); })))),
        React.createElement("div", { className: "section" },
            React.createElement("div", { className: "col-md-4" },
                React.createElement("label", { className: "font" }, "Attachments"),
                attachments.length > 0 && (React.createElement("ul", null, attachments.map(function (file, index) { return (React.createElement("li", { key: index },
                    React.createElement("a", { href: file.ServerRelativeUrl, target: "_blank", rel: "noopener noreferrer" }, file.Name),
                    React.createElement("button", { type: "button", style: { marginLeft: "10px", color: "red" }, onClick: function () { return handleDeleteExistingFile(file); } }, "Delete"))); }))),
                React.createElement("input", { type: "file", multiple: true, className: "form-control", onChange: function (e) {
                        if (e.target.files) {
                            setSelectedFiles(Array.from(e.target.files));
                        }
                    } }))),
        React.createElement("div", { className: "actions" },
            React.createElement("button", { className: "primary", onClick: handleSubmit }, "Submit"),
            React.createElement("button", { className: "exit", onClick: handleExit }, "Exit"))));
};
exports.default = EditAdvanceForm;
//# sourceMappingURL=EditAdvanceForm.js.map