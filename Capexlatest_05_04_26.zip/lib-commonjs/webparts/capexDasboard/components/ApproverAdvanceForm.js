"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var tslib_1 = require("tslib");
var React = tslib_1.__importStar(require("react"));
require("./advanced.scss");
var sp_1 = require("@pnp/sp");
var all_1 = require("@pnp/sp/presets/all");
var react_1 = require("react");
var PeoplePicker_1 = require("@pnp/spfx-controls-react/lib/PeoplePicker");
var ApproverAdvanceForm = function (_a) {
    var _b;
    var context = _a.context, itemId = _a.itemId;
    var sp = (0, sp_1.spfi)().using((0, all_1.SPFx)(context));
    var _c = (0, react_1.useState)(""), selectedVendorName = _c[0], setSelectedVendorName = _c[1];
    var _d = (0, react_1.useState)(null), itemData = _d[0], setItemData = _d[1];
    var _e = (0, react_1.useState)(""), approverRemarks = _e[0], setApproverRemarks = _e[1];
    var _f = (0, react_1.useState)([]), attachments = _f[0], setAttachments = _f[1];
    var _g = (0, react_1.useState)([]), selectedFiles = _g[0], setSelectedFiles = _g[1];
    var _h = (0, react_1.useState)([]), vendors = _h[0], setVendors = _h[1];
    var _j = (0, react_1.useState)(null), selectedVendorId = _j[0], setSelectedVendorId = _j[1];
    var _k = (0, react_1.useState)([]), approvalMatrix = _k[0], setApprovalMatrix = _k[1];
    var _l = (0, react_1.useState)([]), workflowHistory = _l[0], setWorkflowHistory = _l[1];
    var peoplePickerContext = {
        absoluteUrl: context.pageContext.web.absoluteUrl,
        msGraphClientFactory: context.msGraphClientFactory,
        spHttpClient: context.spHttpClient,
    };
    var getAttachments = function (capexId) { return tslib_1.__awaiter(void 0, void 0, void 0, function () {
        var safeCapexId, folderPath, files, error_1;
        return tslib_1.__generator(this, function (_a) {
            switch (_a.label) {
                case 0:
                    debugger;
                    _a.label = 1;
                case 1:
                    _a.trys.push([1, 3, , 4]);
                    if (!capexId)
                        return [2 /*return*/];
                    safeCapexId = capexId.replace(/\//g, "_");
                    folderPath = "CapexAdvanceDocs/".concat(safeCapexId);
                    console.log("Folder Path:", folderPath);
                    return [4 /*yield*/, sp.web
                            .getFolderByServerRelativePath(folderPath)
                            .files()];
                case 2:
                    files = _a.sent();
                    console.log("Files:", files);
                    setAttachments(files || []);
                    return [3 /*break*/, 4];
                case 3:
                    error_1 = _a.sent();
                    console.log("Attachment fetch error:", error_1);
                    setAttachments([]);
                    return [3 /*break*/, 4];
                case 4: return [2 /*return*/];
            }
        });
    }); };
    var uploadAttachments = function (capexId) { return tslib_1.__awaiter(void 0, void 0, void 0, function () {
        var safeCapexId, folderPath, _i, attachments_1, file, error_2;
        return tslib_1.__generator(this, function (_a) {
            switch (_a.label) {
                case 0:
                    _a.trys.push([0, 6, , 7]);
                    if (attachments.length === 0)
                        return [2 /*return*/];
                    safeCapexId = capexId.replace(/\//g, "_");
                    folderPath = "CapexAdvanceDocs/".concat(safeCapexId);
                    return [4 /*yield*/, sp.web.folders.addUsingPath(folderPath)];
                case 1:
                    _a.sent();
                    _i = 0, attachments_1 = attachments;
                    _a.label = 2;
                case 2:
                    if (!(_i < attachments_1.length)) return [3 /*break*/, 5];
                    file = attachments_1[_i];
                    return [4 /*yield*/, sp.web
                            .getFolderByServerRelativePath(folderPath)
                            .files.addUsingPath(file.name, file, { Overwrite: true })];
                case 3:
                    _a.sent();
                    _a.label = 4;
                case 4:
                    _i++;
                    return [3 /*break*/, 2];
                case 5: return [3 /*break*/, 7];
                case 6:
                    error_2 = _a.sent();
                    console.error("Upload error:", error_2);
                    return [3 /*break*/, 7];
                case 7: return [2 /*return*/];
            }
        });
    }); };
    var getVendors = function () { return tslib_1.__awaiter(void 0, void 0, void 0, function () {
        var data, error_3;
        return tslib_1.__generator(this, function (_a) {
            switch (_a.label) {
                case 0:
                    _a.trys.push([0, 2, , 3]);
                    return [4 /*yield*/, sp.web.lists
                            .getByTitle("VendorMaster")
                            .items.select("Id", "VendorCode", "VendorName")()];
                case 1:
                    data = _a.sent();
                    setVendors(data);
                    return [3 /*break*/, 3];
                case 2:
                    error_3 = _a.sent();
                    console.error("Vendor fetch error:", error_3);
                    return [3 /*break*/, 3];
                case 3: return [2 /*return*/];
            }
        });
    }); };
    // ✅ Fetch Item by ID
    var getItemById = function () { return tslib_1.__awaiter(void 0, void 0, void 0, function () {
        var item, parsed, parsed, error_4;
        var _a;
        return tslib_1.__generator(this, function (_b) {
            switch (_b.label) {
                case 0:
                    _b.trys.push([0, 4, , 5]);
                    return [4 /*yield*/, sp.web.lists
                            .getByTitle("CapexAdvance")
                            .items.getById(itemId)
                            .select("*", "PICName/Title", "VendorCode/Id", "VendorCode/VendorCode")
                            .expand("PICName", "VendorCode")()];
                case 1:
                    item = _b.sent();
                    setItemData(item);
                    //setApproverRemarks(item.ApproverRemarks || "");
                    // ✅ FIX: Set VendorId + Name
                    setSelectedVendorId(((_a = item.VendorCode) === null || _a === void 0 ? void 0 : _a.Id) || null);
                    // 🔥 IMPORTANT
                    setSelectedVendorName(item.VendorName); // optional
                    if (!item.CapexID) return [3 /*break*/, 3];
                    return [4 /*yield*/, getAttachments(item.CapexID)];
                case 2:
                    _b.sent();
                    _b.label = 3;
                case 3:
                    if (item.ApprovalMatrix) {
                        try {
                            parsed = typeof item.ApprovalMatrix === "string"
                                ? JSON.parse(item.ApprovalMatrix)
                                : item.ApprovalMatrix;
                            setApprovalMatrix(Array.isArray(parsed) ? parsed : []);
                        }
                        catch (e) {
                            console.error("ApprovalMatrix parse error", e);
                            setApprovalMatrix([]);
                        }
                    }
                    else {
                        setApprovalMatrix([]);
                    }
                    if (item.WorkFlowHistory) {
                        try {
                            parsed = typeof item.WorkFlowHistory === "string"
                                ? JSON.parse(item.WorkFlowHistory)
                                : item.WorkFlowHistory;
                            setWorkflowHistory(Array.isArray(parsed) ? parsed : []);
                        }
                        catch (e) {
                            console.error("WorkFlowHistory parse error", e);
                            setWorkflowHistory([]);
                        }
                    }
                    else {
                        setWorkflowHistory([]);
                    }
                    return [3 /*break*/, 5];
                case 4:
                    error_4 = _b.sent();
                    console.error("Fetch error:", error_4);
                    return [3 /*break*/, 5];
                case 5: return [2 /*return*/];
            }
        });
    }); };
    (0, react_1.useEffect)(function () {
        if (!context || !itemId)
            return;
        var loadData = function () { return tslib_1.__awaiter(void 0, void 0, void 0, function () {
            return tslib_1.__generator(this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, getItemById()];
                    case 1:
                        _a.sent(); // 👈 FIRST load item to get VendorCode
                        return [4 /*yield*/, getVendors()];
                    case 2:
                        _a.sent(); // 👈 FIRST load vendors
                        return [4 /*yield*/, getItemById()];
                    case 3:
                        _a.sent(); // 👈 THEN item
                        return [2 /*return*/];
                }
            });
        }); };
        void loadData();
    }, [context, itemId]);
    // ✅ Approve
    var buildApprovalFlow = function () { return tslib_1.__awaiter(void 0, void 0, void 0, function () {
        var existingFlow, baseApprovers_1, matrixData, matrixApprovers, fullFlow, uniqueFlow, error_5;
        return tslib_1.__generator(this, function (_a) {
            switch (_a.label) {
                case 0:
                    _a.trys.push([0, 2, , 3]);
                    existingFlow = itemData.ApprovalMatrix
                        ? JSON.parse(itemData.ApprovalMatrix)
                        : [];
                    baseApprovers_1 = existingFlow.filter(function (a) { return a.Role === "RM" || a.Role === "HOD"; });
                    return [4 /*yield*/, sp.web.lists
                            .getByTitle("CapexApprovalMatrix")
                            .items
                            .select("Role/RoleName,Approver/Id,Approver/Title,Level/Level")
                            .expand("Approver,Role,Level")
                            .filter("Status eq 'Active'")
                            .orderBy("Level", true)()];
                case 1:
                    matrixData = _a.sent();
                    matrixApprovers = matrixData.map(function (item, index) {
                        var _a, _b, _c;
                        return ({
                            Id: (_a = item.Approver) === null || _a === void 0 ? void 0 : _a.Id,
                            Name: (_b = item.Approver) === null || _b === void 0 ? void 0 : _b.Title,
                            Role: (_c = item.Role) === null || _c === void 0 ? void 0 : _c.RoleName,
                            Level: baseApprovers_1.length + index + 1,
                            Status: "Pending"
                        });
                    });
                    fullFlow = tslib_1.__spreadArray(tslib_1.__spreadArray([], baseApprovers_1, true), matrixApprovers, true);
                    uniqueFlow = fullFlow.filter(function (v, i, self) { return self.findIndex(function (x) { return x.Id === v.Id; }) === i; });
                    return [2 /*return*/, uniqueFlow];
                case 2:
                    error_5 = _a.sent();
                    console.error("Approval Flow Error:", error_5);
                    return [2 /*return*/, []];
                case 3: return [2 /*return*/];
            }
        });
    }); };
    var handleApprove = function () { return tslib_1.__awaiter(void 0, void 0, void 0, function () {
        var existingFlow, latestFlow, isChanged, i, userEmail, currentUserId_1, currentIndex, nextApproverId, finalStatus, currentRole, history_1, error_6;
        var _a, _b;
        return tslib_1.__generator(this, function (_c) {
            switch (_c.label) {
                case 0:
                    _c.trys.push([0, 3, , 4]);
                    if (!approverRemarks) {
                        alert("Please enter Remarks");
                        return [2 /*return*/];
                    }
                    existingFlow = itemData.ApprovalMatrix
                        ? JSON.parse(itemData.ApprovalMatrix)
                        : [];
                    return [4 /*yield*/, buildApprovalFlow()];
                case 1:
                    latestFlow = _c.sent();
                    isChanged = false;
                    if (latestFlow.length !== existingFlow.length) {
                        isChanged = true;
                    }
                    else {
                        for (i = 0; i < latestFlow.length; i++) {
                            if (latestFlow[i].Id !== ((_a = existingFlow[i]) === null || _a === void 0 ? void 0 : _a.Id)) {
                                isChanged = true;
                                break;
                            }
                        }
                    }
                    // =========================
                    // 🔥 IF CHANGED → RESET FLOW
                    // =========================
                    if (isChanged) {
                        existingFlow = latestFlow;
                        // reset all
                        existingFlow.forEach(function (a) { return (a.Status = "Pending"); });
                        if (existingFlow.length > 0) {
                            existingFlow[0].Status = "In Progress";
                        }
                    }
                    userEmail = context.pageContext.user.email;
                    currentUserId_1 = context.pageContext.legacyPageContext.userId;
                    currentIndex = existingFlow.findIndex(function (a) { return a.Id === currentUserId_1; });
                    if (currentIndex === -1) {
                        alert("You are not the current approver");
                        return [2 /*return*/];
                    }
                    // =========================
                    // 🔹 UPDATE CURRENT APPROVER
                    // =========================
                    existingFlow[currentIndex].Status = "Approved";
                    nextApproverId = null;
                    if (existingFlow[currentIndex + 1]) {
                        existingFlow[currentIndex + 1].Status = "In Progress";
                        nextApproverId = existingFlow[currentIndex + 1].Id;
                    }
                    finalStatus = itemData.Status;
                    currentRole = (_b = existingFlow[currentIndex]) === null || _b === void 0 ? void 0 : _b.Role;
                    if (currentRole === "RM") {
                        finalStatus = "Pending for Approver";
                    }
                    else if (currentRole === "HOD") {
                        finalStatus = "Pending for PF Approver";
                    }
                    else {
                        finalStatus = nextApproverId ? "Pending" : "Approved";
                    }
                    history_1 = itemData.WorkFlowHistory
                        ? JSON.parse(itemData.WorkFlowHistory)
                        : [];
                    history_1.push({
                        CurrentApprover: context.pageContext.user.displayName,
                        ActionTaken: "Approved",
                        Comment: approverRemarks,
                        Date: new Date().toISOString()
                    });
                    // =========================
                    // 🔥 UPDATE SHAREPOINT
                    // =========================
                    return [4 /*yield*/, sp.web.lists
                            .getByTitle("CapexAdvance")
                            .items.getById(itemId)
                            .update({
                            ApproverRemarks: approverRemarks,
                            Status: finalStatus, // ✅ FIXED
                            ApprovalMatrix: JSON.stringify(existingFlow),
                            CurrentApproverId: nextApproverId,
                            WorkFlowHistory: JSON.stringify(history_1)
                        })];
                case 2:
                    // =========================
                    // 🔥 UPDATE SHAREPOINT
                    // =========================
                    _c.sent();
                    alert("Approved successfully ✅");
                    window.location.href =
                        "https://isriglobal.sharepoint.com/sites/SonaFinance/SitePages/CapexForm.aspx?page=Approver";
                    return [3 /*break*/, 4];
                case 3:
                    error_6 = _c.sent();
                    console.error("Approve error:", error_6);
                    alert("Error ❌");
                    return [3 /*break*/, 4];
                case 4: return [2 /*return*/];
            }
        });
    }); };
    // ✅ Sent Back
    var handleSendBack = function () { return tslib_1.__awaiter(void 0, void 0, void 0, function () {
        var flow, currentUserId_2, currentIndex, history_2, error_7;
        return tslib_1.__generator(this, function (_a) {
            switch (_a.label) {
                case 0:
                    _a.trys.push([0, 2, , 3]);
                    if (!approverRemarks) {
                        alert("Please enter Remarks");
                        return [2 /*return*/];
                    }
                    flow = itemData.ApprovalMatrix
                        ? JSON.parse(itemData.ApprovalMatrix)
                        : [];
                    currentUserId_2 = context.pageContext.legacyPageContext.userId;
                    currentIndex = flow.findIndex(function (a) { return a.Id === currentUserId_2; });
                    if (currentIndex !== -1) {
                        flow[currentIndex].Status = "Send Back";
                    }
                    history_2 = itemData.WorkFlowHistory
                        ? JSON.parse(itemData.WorkFlowHistory)
                        : [];
                    history_2.push({
                        CurrentApprover: context.pageContext.user.displayName,
                        ActionTaken: "Send Back",
                        Comment: approverRemarks,
                        Date: new Date().toISOString()
                    });
                    return [4 /*yield*/, sp.web.lists
                            .getByTitle("CapexAdvance")
                            .items.getById(itemId)
                            .update({
                            ApproverRemarks: approverRemarks,
                            Status: "Send Back",
                            ApprovalMatrix: JSON.stringify(flow),
                            WorkFlowHistory: JSON.stringify(history_2),
                            CurrentApproverId: itemData.CurrentApproverId
                        })];
                case 1:
                    _a.sent();
                    alert("Send Back ✅");
                    window.location.href = "https://isriglobal.sharepoint.com/sites/SonaFinance/SitePages/CapexForm.aspx?page=Approver";
                    return [3 /*break*/, 3];
                case 2:
                    error_7 = _a.sent();
                    console.error(error_7);
                    return [3 /*break*/, 3];
                case 3: return [2 /*return*/];
            }
        });
    }); };
    // ✅ Reject
    var handleReject = function () { return tslib_1.__awaiter(void 0, void 0, void 0, function () {
        var flow, currentUserId_3, currentIndex, history_3, error_8;
        return tslib_1.__generator(this, function (_a) {
            switch (_a.label) {
                case 0:
                    _a.trys.push([0, 2, , 3]);
                    if (!approverRemarks) {
                        alert("Please enter Remarks");
                        return [2 /*return*/];
                    }
                    flow = itemData.ApprovalMatrix
                        ? JSON.parse(itemData.ApprovalMatrix)
                        : [];
                    currentUserId_3 = context.pageContext.legacyPageContext.userId;
                    currentIndex = flow.findIndex(function (a) { return a.Id === currentUserId_3; });
                    if (currentIndex !== -1) {
                        flow[currentIndex].Status = "Rejected";
                    }
                    history_3 = itemData.WorkFlowHistory
                        ? JSON.parse(itemData.WorkFlowHistory)
                        : [];
                    history_3.push({
                        CurrentApprover: context.pageContext.user.displayName,
                        ActionTaken: "Rejected",
                        Comment: approverRemarks,
                        Date: new Date().toISOString()
                    });
                    return [4 /*yield*/, sp.web.lists
                            .getByTitle("CapexAdvance")
                            .items.getById(itemId)
                            .update({
                            ApproverRemarks: approverRemarks,
                            Status: "Rejected",
                            ApprovalMatrix: JSON.stringify(flow),
                            WorkFlowHistory: JSON.stringify(history_3),
                            CurrentApproverId: null
                        })];
                case 1:
                    _a.sent();
                    alert("Rejected ❌");
                    window.location.href = "https://isriglobal.sharepoint.com/sites/SonaFinance/SitePages/CapexForm.aspx?page=Approver";
                    return [3 /*break*/, 3];
                case 2:
                    error_8 = _a.sent();
                    console.error(error_8);
                    return [3 /*break*/, 3];
                case 3: return [2 /*return*/];
            }
        });
    }); };
    var handleExit = function () {
        window.location.href = "https://isriglobal.sharepoint.com/sites/SonaFinance/SitePages/CapexForm.aspx?page=Approver";
    };
    // ⛔ Wait until data loads
    if (!itemData)
        return React.createElement("div", null, "Loading...");
    return (React.createElement("div", { className: "form-container" },
        React.createElement("h2", { className: "form-title" }, "Advance Payment (Approver)"),
        React.createElement("div", { className: "section" },
            React.createElement("h3", null, "Approval Matrix"),
            React.createElement("div", { className: "approval-flow" }, approvalMatrix.length === 0 ? (React.createElement("p", null, "No approval data")) : (approvalMatrix.map(function (a, index) { return (React.createElement("div", { key: index, className: "approval-step ".concat(a.Status === "In Progress"
                    ? "active"
                    : a.Status === "Approved"
                        ? "approved"
                        : "") },
                React.createElement("div", null,
                    React.createElement("b", null, a.Role)),
                React.createElement("div", null, a.Name),
                React.createElement("div", { className: "status" }, a.Status))); })))),
        React.createElement("div", { className: "section" },
            React.createElement("h3", null, "Requestor Information"),
            React.createElement("div", { className: "form-row" },
                React.createElement("label", null, "Employee Code"),
                React.createElement("input", { value: itemData.EmployeeCode || "", readOnly: true }),
                React.createElement("label", null, "Employee Name"),
                React.createElement("input", { value: itemData.EmployeeName || "", readOnly: true }),
                React.createElement("label", null, "Division"),
                React.createElement("input", { value: itemData.Division || "", readOnly: true }),
                React.createElement("label", null, "Location"),
                React.createElement("input", { value: itemData.Location || "", readOnly: true })),
            React.createElement("div", { className: "form-row" },
                React.createElement("label", null, "Email"),
                React.createElement("input", { value: itemData.Email || "", readOnly: true }),
                React.createElement("label", null, "RM"),
                React.createElement("input", { value: itemData.RM || "", readOnly: true }),
                React.createElement("label", null, "HOD"),
                React.createElement("input", { value: itemData.HOD || "", readOnly: true }),
                React.createElement("label", null, "Contact No"),
                React.createElement("input", { value: itemData.ContactNo || "", readOnly: true }))),
        React.createElement("div", { className: "section" },
            React.createElement("h3", null, "Vendor & PO Details"),
            React.createElement("div", { className: "form-row" },
                React.createElement("label", null, "Vendor Code"),
                React.createElement("select", { value: selectedVendorId !== null && selectedVendorId !== void 0 ? selectedVendorId : "", disabled: true, onChange: function (e) {
                        var id = Number(e.target.value);
                        var vendor = vendors.find(function (v) { return v.Id === id; });
                        setSelectedVendorId(id);
                        setSelectedVendorName((vendor === null || vendor === void 0 ? void 0 : vendor.VendorName) || "");
                    } },
                    React.createElement("option", { value: "" }, "Select Vendor"),
                    vendors.map(function (v) { return (React.createElement("option", { key: v.Id, value: v.Id }, v.VendorCode)); })),
                React.createElement("label", null, "Vendor Name"),
                React.createElement("input", { value: itemData.VendorName || "", readOnly: true }),
                React.createElement("label", null, "PO Number"),
                React.createElement("input", { value: itemData.PONumber || "", readOnly: true }),
                React.createElement("label", null, "PO Date"),
                React.createElement("input", { value: itemData.PODate
                        ? new Date(itemData.PODate).toLocaleDateString("en-GB")
                        : "", readOnly: true })),
            React.createElement("div", { className: "form-row" },
                React.createElement("label", null, "PO Terms"),
                React.createElement("input", { value: itemData.POAdvanceTerms || "", readOnly: true }),
                React.createElement("label", null, "PO Amount"),
                React.createElement("input", { value: itemData.POAmtGST || "", readOnly: true }),
                React.createElement("label", null, "Advance Amount"),
                React.createElement("input", { value: itemData.RequestAdvanceAmount || "", readOnly: true }),
                React.createElement("label", null, "Paid Amount"),
                React.createElement("input", { value: itemData.PaidAmount || "", readOnly: true }))),
        React.createElement("div", { className: "section" },
            React.createElement("h3", null, "Advance Details"),
            React.createElement("div", { className: "form-row" },
                React.createElement("label", null, "Expected Settlement"),
                React.createElement("input", { value: itemData.ExpectedDateofSettlement
                        ? new Date(itemData.ExpectedDateofSettlement).toLocaleDateString("en-GB")
                        : "", readOnly: true }),
                React.createElement("label", null, "PIC Name"),
                React.createElement(PeoplePicker_1.PeoplePicker, { context: peoplePickerContext, personSelectionLimit: 1, disabled: true, principalTypes: [PeoplePicker_1.PrincipalType.User], defaultSelectedUsers: ((_b = itemData === null || itemData === void 0 ? void 0 : itemData.PICName) === null || _b === void 0 ? void 0 : _b.Title) ? [itemData.PICName.Title] : [] }),
                React.createElement("label", null, "GL Code"),
                React.createElement("input", { value: itemData.GL || "", readOnly: true }),
                React.createElement("label", null, "Cost Center"),
                React.createElement("input", { value: itemData.CostCenter || "", readOnly: true }))),
        React.createElement("div", { className: "section" },
            React.createElement("h3", null, "Remarks"),
            React.createElement("div", { className: "form-row" },
                React.createElement("label", null, "User Remarks"),
                React.createElement("textarea", { value: itemData.Remarks || "", readOnly: true }),
                React.createElement("label", null, "Project Description"),
                React.createElement("textarea", { value: itemData.ProjectDescription || "", readOnly: true }))),
        React.createElement("div", { className: "section" },
            React.createElement("h3", null, "Workflow History"),
            workflowHistory.length === 0 ? (React.createElement("p", null, "No history available")) : (React.createElement("div", { className: "workflow-history" }, workflowHistory.map(function (h, index) { return (React.createElement("div", { key: index, className: "history-item" },
                React.createElement("div", null,
                    React.createElement("b", null, h.ActionTaken)),
                React.createElement("div", null, h.CurrentApprover),
                React.createElement("div", null, h.Comment),
                React.createElement("div", { className: "date" }, new Date(h.Date).toLocaleString()))); })))),
        React.createElement("div", { className: "section" },
            React.createElement("h3", null, "Approver Action"),
            React.createElement("label", null, "Approver Remarks"),
            React.createElement("textarea", { value: approverRemarks, onChange: function (e) { return setApproverRemarks(e.target.value); } })),
        React.createElement("div", { className: "section" },
            React.createElement("h3", null, "Attachments"),
            attachments.length === 0 ? (React.createElement("p", null, "No attachments found")) : (React.createElement("ul", null, attachments.map(function (file, index) { return (React.createElement("li", { key: index },
                React.createElement("a", { href: file.ServerRelativeUrl, target: "_blank" }, file.Name))); })))),
        React.createElement("div", { className: "actions" },
            React.createElement("button", { className: "primary", onClick: handleApprove }, "Approve"),
            React.createElement("button", { className: "secondary", onClick: handleSendBack }, "Sent Back"),
            React.createElement("button", { className: "secondary", onClick: handleReject }, "Reject"),
            React.createElement("button", { className: "exit", onClick: handleExit }, "Exit"))));
};
exports.default = ApproverAdvanceForm;
//# sourceMappingURL=ApproverAdvanceForm.js.map