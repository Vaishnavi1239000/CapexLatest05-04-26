"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.default = CapexDasboard;
var tslib_1 = require("tslib");
var React = tslib_1.__importStar(require("react"));
require("./usersite.scss");
var UserDashboard_1 = tslib_1.__importDefault(require("./UserDashboard"));
var ApproverDashboard_1 = tslib_1.__importDefault(require("./ApproverDashboard"));
var APperformerDashboard_1 = tslib_1.__importDefault(require("./APperformerDashboard"));
function CapexDasboard(props) {
    var _a = React.useState("home"), page = _a[0], setPage = _a[1];
    // ✅ Navigation function (updates URL + state)
    var navigate = function (pageName) {
        var url = "".concat(props.context.pageContext.web.absoluteUrl, "/SitePages/CapexForm.aspx?page=").concat(pageName);
        window.history.pushState({}, "", url);
        setPage(pageName);
    };
    // ✅ On page load → read URL
    React.useEffect(function () {
        var params = new URLSearchParams(window.location.search);
        var pageParam = params.get("page");
        if (pageParam) {
            setPage(pageParam);
        }
    }, []);
    // ✅ Handle browser back/forward
    React.useEffect(function () {
        var handlePopState = function () {
            var params = new URLSearchParams(window.location.search);
            var pageParam = params.get("page") || "home";
            setPage(pageParam);
        };
        window.addEventListener("popstate", handlePopState);
        return function () {
            window.removeEventListener("popstate", handlePopState);
        };
    }, []);
    return (React.createElement("div", null,
        page === "home" && (React.createElement("div", { className: "main-container" },
            React.createElement("h1", { className: "title" }, "Capex Advance form"),
            React.createElement("div", { className: "buttonGrid" },
                React.createElement("button", { className: "btn", onClick: function () { return navigate("User"); } }, "User Dashboard"),
                React.createElement("button", { className: "btn", onClick: function () { return navigate("Approver"); } }, "Approver Dashboard"),
                React.createElement("button", { className: "btn fullWidth", onClick: function () { return navigate("Performer"); } }, "AP Performer Dashboard")))),
        page === "User" && (React.createElement(UserDashboard_1.default, { context: props.context })),
        page === "Approver" && (React.createElement(ApproverDashboard_1.default, { context: props.context })),
        page === "Performer" && (React.createElement(APperformerDashboard_1.default, { context: props.context }))));
}
//# sourceMappingURL=CapexDasboard.js.map