"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var tslib_1 = require("tslib");
var React = tslib_1.__importStar(require("react"));
require("./userDashboardsc.scss");
var react_1 = require("react");
var APperformerAdvanceFormForUTR_1 = tslib_1.__importDefault(require("./APperformerAdvanceFormForUTR"));
var SonaPNGLogo_png_1 = tslib_1.__importDefault(require("../assets/SonaPNGLogo.png"));
var userlogo_png_1 = tslib_1.__importDefault(require("../assets/userlogo.png"));
require("../assets/bootstrap/css/bootstrap.css");
var sp_1 = require("@pnp/sp");
var all_1 = require("@pnp/sp/presets/all");
var APperformerdashboardforutr = function (_a) {
    var context = _a.context;
    var sp = (0, sp_1.spfi)().using((0, all_1.SPFx)(context));
    //const [formType, setFormType] = useState<"new" | "view" | null>(null);
    var _b = (0, react_1.useState)(null), formType = _b[0], setFormType = _b[1];
    var _c = React.useState("My Request"), activeMenu = _c[0], setActiveMenu = _c[1];
    var _d = React.useState(""), searchText = _d[0], setSearchText = _d[1];
    var _e = React.useState(""), statusFilter = _e[0], setStatusFilter = _e[1];
    var _f = React.useState(false), showForm = _f[0], setShowForm = _f[1];
    var _g = React.useState([]), data = _g[0], setData = _g[1];
    var _h = React.useState(""), currentUserName = _h[0], setCurrentUserName = _h[1];
    var _j = React.useState(null), selectedItem = _j[0], setSelectedItem = _j[1];
    var _k = React.useState(null), CurrentUserId = _k[0], setCurrentUserId = _k[1];
    // ✅ GET CURRENT USER
    var getLoggedInUser = function () { return tslib_1.__awaiter(void 0, void 0, void 0, function () {
        var user, error_1;
        return tslib_1.__generator(this, function (_a) {
            switch (_a.label) {
                case 0:
                    _a.trys.push([0, 2, , 3]);
                    return [4 /*yield*/, sp.web.currentUser()];
                case 1:
                    user = _a.sent();
                    setCurrentUserName(user.Title);
                    setCurrentUserId(user.Id);
                    return [3 /*break*/, 3];
                case 2:
                    error_1 = _a.sent();
                    console.error("User error:", error_1);
                    return [3 /*break*/, 3];
                case 3: return [2 /*return*/];
            }
        });
    }); };
    var handleApproveClick = function (item) { return tslib_1.__awaiter(void 0, void 0, void 0, function () {
        var fullItem, error_2;
        return tslib_1.__generator(this, function (_a) {
            switch (_a.label) {
                case 0:
                    _a.trys.push([0, 2, , 3]);
                    return [4 /*yield*/, sp.web.lists
                            .getByTitle("CapexAdvance")
                            .items.getById(item.ID)
                            .select("*", "PICName/Title")
                            .expand("PICName")()];
                case 1:
                    fullItem = _a.sent();
                    setSelectedItem(fullItem);
                    setFormType("approve"); // 👈 important
                    setShowForm(true);
                    return [3 /*break*/, 3];
                case 2:
                    error_2 = _a.sent();
                    console.error("Approve error:", error_2);
                    return [3 /*break*/, 3];
                case 3: return [2 /*return*/];
            }
        });
    }); };
    var getCapexData = function () { return tslib_1.__awaiter(void 0, void 0, void 0, function () {
        var user, userId, items, formatted, error_3;
        return tslib_1.__generator(this, function (_a) {
            switch (_a.label) {
                case 0:
                    _a.trys.push([0, 3, , 4]);
                    return [4 /*yield*/, sp.web.currentUser()];
                case 1:
                    user = _a.sent();
                    userId = user.Id;
                    return [4 /*yield*/, sp.web.lists
                            .getByTitle("CapexAdvance")
                            .items
                            .select("ID", "Title", "Created", "EmployeeName", "VendorName", "PONumber", "RequestAdvanceAmount", "Status").filter("Status eq 'pending for PF Approver UTR'  and CurrentApproverId eq '".concat(userId, "'")) // ✅ FILTER HERE
                            .orderBy("ID", false)()];
                case 2:
                    items = _a.sent();
                    formatted = items.map(function (item) { return ({
                        ID: item.ID,
                        id: item.Title,
                        date: item.Created
                            ? new Date(item.Created).toLocaleDateString("en-GB")
                            : "",
                        EmployeeName: item.EmployeeName,
                        vendor: item.VendorName || "",
                        po: item.PONumber || "",
                        amount: item.RequestAdvanceAmount || 0,
                        status: item.Status || ""
                    }); });
                    setData(formatted);
                    return [3 /*break*/, 4];
                case 3:
                    error_3 = _a.sent();
                    console.error("Data error:", error_3);
                    return [3 /*break*/, 4];
                case 4: return [2 /*return*/];
            }
        });
    }); };
    // ✅ GET LIST DATA
    // ✅ VIEW CLICK
    var handleViewClick = function (item) { return tslib_1.__awaiter(void 0, void 0, void 0, function () {
        var fullItem, error_4;
        return tslib_1.__generator(this, function (_a) {
            switch (_a.label) {
                case 0:
                    _a.trys.push([0, 2, , 3]);
                    return [4 /*yield*/, sp.web.lists
                            .getByTitle("CapexAdvance")
                            .items.getById(item.ID)
                            .select("*", "PICName/Title")
                            .expand("PICName")()];
                case 1:
                    fullItem = _a.sent();
                    setSelectedItem(fullItem);
                    setFormType("view");
                    setShowForm(true);
                    return [3 /*break*/, 3];
                case 2:
                    error_4 = _a.sent();
                    console.error("View error:", error_4);
                    return [3 /*break*/, 3];
                case 3: return [2 /*return*/];
            }
        });
    }); };
    var filteredData = data.filter(function (item) {
        var _a, _b, _c, _d, _e, _f;
        var text = searchText.toLowerCase();
        var status = statusFilter.toLowerCase();
        var menuFilter = true;
        if (activeMenu === "Paid") {
            menuFilter = ((_a = item.status) === null || _a === void 0 ? void 0 : _a.toLowerCase()) === "paid";
        }
        else if (activeMenu === "Rejected") {
            menuFilter = ((_b = item.status) === null || _b === void 0 ? void 0 : _b.toLowerCase()) === "rejected";
        }
        else if (activeMenu === "My Request") {
            menuFilter = true;
        }
        return (menuFilter &&
            (((_c = item.id) === null || _c === void 0 ? void 0 : _c.toLowerCase().includes(text)) ||
                ((_d = item.vendor) === null || _d === void 0 ? void 0 : _d.toLowerCase().includes(text)) ||
                ((_e = item.po) === null || _e === void 0 ? void 0 : _e.toLowerCase().includes(text))) &&
            (!status || ((_f = item.status) === null || _f === void 0 ? void 0 : _f.toLowerCase().includes(status))));
    });
    // ✅ LOAD DATA
    React.useEffect(function () {
        if (!context)
            return;
        void getLoggedInUser();
        void getCapexData();
    }, [context]);
    if (showForm) {
        if (formType === "approve") {
            return (React.createElement(APperformerAdvanceFormForUTR_1.default, { context: context, itemId: selectedItem === null || selectedItem === void 0 ? void 0 : selectedItem.ID }));
        }
    }
    return (React.createElement("div", { style: { display: "flex" } },
        React.createElement("div", { className: "sidebarmenu", style: {
                width: "200px",
                background: "black",
                color: "white",
                height: "100vh",
                paddingTop: "20px",
                textAlign: "center"
            } },
            React.createElement("h3", { className: activeMenu === "My Request" ? "active" : "", onClick: function () { return setActiveMenu("My Request"); } }, "My Request"),
            React.createElement("h3", { className: activeMenu === "Paid" ? "active" : "", onClick: function () { return setActiveMenu("Paid"); } }, "Paid"),
            React.createElement("h3", { className: activeMenu === "Rejected" ? "active" : "", onClick: function () { return setActiveMenu("Rejected"); } }, "Rejected")),
        React.createElement("div", { style: { flex: 1 } },
            React.createElement("div", { className: "row hederbox" },
                React.createElement("div", { className: "d-left" },
                    React.createElement("img", { src: SonaPNGLogo_png_1.default })),
                React.createElement("div", { className: "userinfo" }, currentUserName),
                React.createElement("div", { className: "d-right d-left" },
                    React.createElement("img", { src: userlogo_png_1.default }))),
            React.createElement("div", { className: "subsection" },
                React.createElement("div", { className: "row" },
                    React.createElement("div", { className: "col-md-5" },
                        React.createElement("div", { className: "titlebox" }, "CAPEX Advanced Performer Dashboard")),
                    React.createElement("div", { className: "col-md-7" },
                        React.createElement("div", { className: "row" },
                            React.createElement("div", { className: "col-md-4" },
                                React.createElement("input", { placeholder: "Search", value: searchText, onChange: function (e) { return setSearchText(e.target.value); } })),
                            React.createElement("div", { className: "col-md-4" },
                                React.createElement("select", { value: statusFilter, onChange: function (e) { return setStatusFilter(e.target.value); } },
                                    React.createElement("option", { value: "" }, "All"),
                                    React.createElement("option", { value: "Submitted" }, "Submitted"),
                                    React.createElement("option", { value: "Approved" }, "Approved"),
                                    React.createElement("option", { value: "Rejected" }, "Rejected"),
                                    React.createElement("option", { value: "Draft" }, "Draft")))))),
                React.createElement("table", { className: "data-table-section" },
                    React.createElement("thead", null,
                        React.createElement("tr", null,
                            React.createElement("th", null, "Action"),
                            React.createElement("th", null, "Payment ID"),
                            React.createElement("th", null, "Requestor Date"),
                            React.createElement("th", null, "Requestor Name"),
                            React.createElement("th", null, "Requestor Type"),
                            React.createElement("th", null, "Vendor Code"),
                            React.createElement("th", null, "Vendor Name"),
                            React.createElement("th", null, "PO Number"),
                            React.createElement("th", null, "Advance Amount"),
                            React.createElement("th", null, "Pending With"),
                            React.createElement("th", null, "Status"))),
                    React.createElement("tbody", null, filteredData.length === 0 ? (React.createElement("tr", null,
                        React.createElement("td", { colSpan: 7, style: { textAlign: "center" } }, "No Data"))) : (filteredData.map(function (item, i) { return (React.createElement("tr", { key: i },
                        React.createElement("td", { style: { cursor: "pointer" }, onClick: function () { return handleApproveClick(item); } }, "\u270F\uFE0F"),
                        React.createElement("td", null, item.id),
                        React.createElement("td", null, item.date),
                        React.createElement("td", null, item.EmployeeName),
                        React.createElement("td", null, "Capex Advance"),
                        React.createElement("td", null,
                            " ",
                            item.vendorCode),
                        React.createElement("td", null, item.vendor),
                        React.createElement("td", null, item.po),
                        React.createElement("td", null,
                            "\u20B9 ",
                            item.amount),
                        React.createElement("td", null, "Approver"),
                        React.createElement("td", null, item.status))); }))))))));
};
exports.default = APperformerdashboardforutr;
//# sourceMappingURL=APperformerdashboardforutr.js.map