"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var tslib_1 = require("tslib");
var React = tslib_1.__importStar(require("react"));
require("./advanced.scss");
var sp_1 = require("@pnp/sp");
var all_1 = require("@pnp/sp/presets/all");
var react_1 = require("react");
var PeoplePicker_1 = require("@pnp/spfx-controls-react/lib/PeoplePicker");
var ViewAdvanceForm = function (_a) {
    var _b, _c, _d;
    var context = _a.context, formData = _a.formData, onClose = _a.onClose;
    var _e = (0, react_1.useState)([]), attachments = _e[0], setAttachments = _e[1];
    var sp = (0, sp_1.spfi)().using((0, all_1.SPFx)(context));
    var _f = (0, react_1.useState)({}), employee = _f[0], setEmployee = _f[1];
    // 🔹 Employee
    var _g = (0, react_1.useState)([]), selectedFiles = _g[0], setSelectedFiles = _g[1];
    var _h = (0, react_1.useState)([]), selectedUser = _h[0], setSelectedUser = _h[1];
    var _j = (0, react_1.useState)(null), selectedVendorId = _j[0], setSelectedVendorId = _j[1];
    var _k = (0, react_1.useState)(""), selectedVendorName = _k[0], setSelectedVendorName = _k[1];
    var _l = (0, react_1.useState)([]), vendors = _l[0], setVendors = _l[1];
    var _m = (0, react_1.useState)(""), employeeName = _m[0], setEmployeeName = _m[1];
    var _o = (0, react_1.useState)(""), employeeEmail = _o[0], setEmployeeEmail = _o[1];
    var _p = (0, react_1.useState)(null), VendorCode = _p[0], setVendorCode = _p[1];
    // 🔹 Form fields
    var _q = (0, react_1.useState)(""), poNumber = _q[0], setPoNumber = _q[1];
    var _r = (0, react_1.useState)(""), poDate = _r[0], setPoDate = _r[1];
    var _s = (0, react_1.useState)(""), poTerms = _s[0], setPoTerms = _s[1];
    var _t = (0, react_1.useState)(""), poAmount = _t[0], setPoAmount = _t[1];
    var _u = (0, react_1.useState)(""), advanceAmount = _u[0], setAdvanceAmount = _u[1];
    var _v = (0, react_1.useState)(""), paidAmount = _v[0], setPaidAmount = _v[1];
    var _w = (0, react_1.useState)(""), expectedDate = _w[0], setExpectedDate = _w[1];
    var _x = (0, react_1.useState)(""), vendorName = _x[0], setVendorName = _x[1];
    var _y = (0, react_1.useState)(""), glCode = _y[0], setGlCode = _y[1];
    var _z = (0, react_1.useState)(""), costCenter = _z[0], setCostCenter = _z[1];
    var _0 = (0, react_1.useState)(""), remarks = _0[0], setRemarks = _0[1];
    var _1 = (0, react_1.useState)(""), projectDesc = _1[0], setProjectDesc = _1[1];
    // 🔹 Extra fields
    var _2 = (0, react_1.useState)(""), approverRemarks = _2[0], setApproverRemarks = _2[1];
    var _3 = (0, react_1.useState)(""), voucherDate = _3[0], setVoucherDate = _3[1];
    var _4 = (0, react_1.useState)(""), VouchingNumber = _4[0], setVouchingNumber = _4[1];
    var _5 = (0, react_1.useState)(""), UTRDate = _5[0], setUTRDate = _5[1];
    var _6 = (0, react_1.useState)(""), UTRNumber = _6[0], setUTRNumber = _6[1];
    var _7 = (0, react_1.useState)([]), approvalMatrix = _7[0], setApprovalMatrix = _7[1];
    var _8 = (0, react_1.useState)([]), workflowHistory = _8[0], setWorkflowHistory = _8[1];
    var peoplePickerContext = {
        absoluteUrl: context.pageContext.web.absoluteUrl,
        msGraphClientFactory: context.msGraphClientFactory,
        spHttpClient: context.spHttpClient,
    };
    var getAttachments = function (capexId) { return tslib_1.__awaiter(void 0, void 0, void 0, function () {
        var safeCapexId, folderPath, files, error_1;
        return tslib_1.__generator(this, function (_a) {
            switch (_a.label) {
                case 0:
                    _a.trys.push([0, 2, , 3]);
                    if (!capexId)
                        return [2 /*return*/];
                    safeCapexId = capexId.replace(/\//g, "_");
                    folderPath = "/sites/SonaFinance/CapexAdvanceDocs/".concat(safeCapexId);
                    console.log("Folder Path:", folderPath); // ✅ DEBUG
                    return [4 /*yield*/, sp.web
                            .getFolderByServerRelativePath(folderPath)
                            .files()];
                case 1:
                    files = _a.sent();
                    console.log("Files:", files); // ✅ DEBUG
                    setAttachments(files || []);
                    return [3 /*break*/, 3];
                case 2:
                    error_1 = _a.sent();
                    console.log("Attachment fetch error:", error_1);
                    setAttachments([]);
                    return [3 /*break*/, 3];
                case 3: return [2 /*return*/];
            }
        });
    }); };
    var uploadFiles = function () { return tslib_1.__awaiter(void 0, void 0, void 0, function () {
        var safe, path, _i, selectedFiles_1, file;
        return tslib_1.__generator(this, function (_a) {
            switch (_a.label) {
                case 0:
                    if (!(formData === null || formData === void 0 ? void 0 : formData.CapexID) || selectedFiles.length === 0)
                        return [2 /*return*/];
                    safe = formData.CapexID.replace(/\//g, "_");
                    path = "/sites/SonaFinance/CapexAdvanceDocs/".concat(safe);
                    _i = 0, selectedFiles_1 = selectedFiles;
                    _a.label = 1;
                case 1:
                    if (!(_i < selectedFiles_1.length)) return [3 /*break*/, 4];
                    file = selectedFiles_1[_i];
                    return [4 /*yield*/, sp.web
                            .getFolderByServerRelativePath(path)
                            .files.addUsingPath(file.name, file, { Overwrite: true })];
                case 2:
                    _a.sent();
                    _a.label = 3;
                case 3:
                    _i++;
                    return [3 /*break*/, 1];
                case 4:
                    void setSelectedFiles([]);
                    void getAttachments(formData.CapexID);
                    return [2 /*return*/];
            }
        });
    }); };
    // ✅ Fetch Item by ID
    var getVendors = function () { return tslib_1.__awaiter(void 0, void 0, void 0, function () {
        var data;
        return tslib_1.__generator(this, function (_a) {
            switch (_a.label) {
                case 0: return [4 /*yield*/, sp.web.lists
                        .getByTitle("VendorMaster")
                        .items.select("Id", "VendorCode", "VendorName")()];
                case 1:
                    data = _a.sent();
                    void setVendors(data);
                    return [2 /*return*/];
            }
        });
    }); };
    // ✅ Bind SharePoint Data
    (0, react_1.useEffect)(function () {
        var _a, _b, _c, _d, _e;
        if (!formData)
            return;
        setPoNumber(formData.PONumber || "");
        setPoDate(((_a = formData.PODate) === null || _a === void 0 ? void 0 : _a.split("T")[0]) || "");
        setPoTerms(formData.POAdvanceTerms || "");
        setPoAmount(formData.POAmtGST || "");
        setAdvanceAmount(formData.RequestAdvanceAmount || "");
        setPaidAmount(formData.PaidAmount || "");
        setExpectedDate(((_b = formData.ExpectedDateofSettlement) === null || _b === void 0 ? void 0 : _b.split("T")[0]) || "");
        setVendorName(formData.VendorName || "");
        setSelectedVendorId(formData.VendorCodeId || null); // ✅ ADD THIS
        setSelectedVendorName(formData.VendorName || ""); // ✅ ADD THIS
        setGlCode(formData.GL || "");
        setCostCenter(formData.CostCenter || "");
        setRemarks(formData.Remarks || "");
        setProjectDesc(formData.ProjectDescription || "");
        setApproverRemarks(formData.ApproverRemarks || "");
        setVoucherDate(((_c = formData.VoucherDate) === null || _c === void 0 ? void 0 : _c.split("T")[0]) || "");
        setVouchingNumber(formData.VouchingNumber || "");
        setUTRDate(((_d = formData.UTRDate) === null || _d === void 0 ? void 0 : _d.split("T")[0]) || "");
        setUTRNumber(formData.UTRNumber || "");
        // ✅ PIC FIX
        if ((_e = formData === null || formData === void 0 ? void 0 : formData.PICName) === null || _e === void 0 ? void 0 : _e.Title) {
            setSelectedUser([
                {
                    text: formData.PICName.Title,
                    secondaryText: formData.PICName.EMail,
                },
            ]);
        }
        if (formData.CapexID) {
            void getAttachments(formData.CapexID);
        }
        // ✅ Approval Matrix (SAFE)
        if (formData === null || formData === void 0 ? void 0 : formData.ApprovalMatrix) {
            try {
                var parsed = typeof formData.ApprovalMatrix === "string"
                    ? JSON.parse(formData.ApprovalMatrix)
                    : formData.ApprovalMatrix;
                setApprovalMatrix(Array.isArray(parsed) ? parsed : []);
            }
            catch (e) {
                console.error("ApprovalMatrix parse error", e);
                setApprovalMatrix([]);
            }
        }
        else {
            setApprovalMatrix([]);
        }
        // ✅ Workflow History (SAFE)
        if (formData === null || formData === void 0 ? void 0 : formData.WorkFlowHistory) {
            try {
                var parsed = typeof formData.WorkFlowHistory === "string"
                    ? JSON.parse(formData.WorkFlowHistory)
                    : formData.WorkFlowHistory;
                setWorkflowHistory(Array.isArray(parsed) ? parsed : []);
            }
            catch (e) {
                console.error("WorkFlowHistory parse error", e);
                setWorkflowHistory([]);
            }
        }
        else {
            setWorkflowHistory([]);
        }
    }, [formData]);
    var handleExit = function () {
        if (onClose)
            onClose();
        else
            window.location.reload();
    };
    var getLoggedInUser = function () { return tslib_1.__awaiter(void 0, void 0, void 0, function () {
        var currentUser, email, user, error_2;
        return tslib_1.__generator(this, function (_a) {
            switch (_a.label) {
                case 0:
                    _a.trys.push([0, 3, , 4]);
                    return [4 /*yield*/, sp.web.currentUser()];
                case 1:
                    currentUser = _a.sent();
                    email = currentUser.Email;
                    return [4 /*yield*/, sp.web.lists
                            .getByTitle("EmployeeMaster")
                            .items.select("EmployeeCode", "EmployeeName", "Division", "Location", "EmployeeEmail", "ReportingManager/Title", "HOD/Title", "ContactNo", "EmployeeStatus", "CostCenter")
                            .expand("ReportingManager", "HOD")
                            .filter("EmployeeEmail eq '".concat(email, "'"))
                            .top(1)()];
                case 2:
                    user = _a.sent();
                    if (user.length > 0) {
                        setEmployee(user[0]);
                    }
                    return [3 /*break*/, 4];
                case 3:
                    error_2 = _a.sent();
                    console.log("Error fetching user:", error_2);
                    return [3 /*break*/, 4];
                case 4: return [2 /*return*/];
            }
        });
    }); };
    (0, react_1.useEffect)(function () {
        void getLoggedInUser();
        void getVendors();
    }, []);
    return (React.createElement("div", { className: "form-container" },
        React.createElement("h2", null, "Advance Payment (View)"),
        React.createElement("div", { className: "section" },
            React.createElement("h3", null, "Approval Matrix"),
            approvalMatrix.length === 0 ? (React.createElement("p", null, "No approval data")) : (React.createElement("div", { className: "approval-flow" }, approvalMatrix.map(function (a, index) { return (React.createElement("div", { key: index, className: "approval-step ".concat(a.Status === "In Progress"
                    ? "active"
                    : a.Status === "Approved"
                        ? "approved"
                        : a.Status === "Rejected"
                            ? "rejected"
                            : a.Status === "Send Back"
                                ? "sendback"
                                : "") },
                React.createElement("div", null,
                    React.createElement("b", null, a.Role)),
                React.createElement("div", null, a.Name),
                React.createElement("div", null, a.Status))); })))),
        React.createElement("div", { className: "section" },
            React.createElement("h3", null, "Requestor Information"),
            React.createElement("div", { className: "form-row" },
                React.createElement("label", null, "Employee Code"),
                React.createElement("input", { value: employee.EmployeeCode || "", readOnly: true }),
                React.createElement("label", null, "Employee Name"),
                React.createElement("input", { value: employee.EmployeeName || "", readOnly: true }),
                React.createElement("label", null, "Division"),
                React.createElement("input", { value: employee.Division || "", readOnly: true }),
                React.createElement("label", null, "Location"),
                React.createElement("input", { value: employee.Location || "", readOnly: true })),
            React.createElement("div", { className: "form-row" },
                React.createElement("label", null, "Email"),
                React.createElement("input", { value: employee.EmployeeEmail || "", readOnly: true }),
                React.createElement("label", null, "RM"),
                React.createElement("input", { value: ((_b = employee.ReportingManager) === null || _b === void 0 ? void 0 : _b.Title) || "", readOnly: true }),
                React.createElement("label", null, "HOD"),
                React.createElement("input", { value: ((_c = employee.HOD) === null || _c === void 0 ? void 0 : _c.Title) || "", readOnly: true }),
                React.createElement("label", null, "Contact No"),
                React.createElement("input", { value: employee.ContactNo || "", readOnly: true })),
            React.createElement("div", { className: "form-row" },
                React.createElement("label", null, "Employee Status"),
                React.createElement("input", { value: employee.EmployeeStatus || "", readOnly: true }))),
        React.createElement("div", { className: "section" },
            React.createElement("h3", null, "Vendor & PO"),
            React.createElement("label", null, "Vendor Code"),
            React.createElement("select", { value: selectedVendorId !== null && selectedVendorId !== void 0 ? selectedVendorId : "", disabled: true, onChange: function (e) {
                    var id = Number(e.target.value);
                    var vendor = vendors.find(function (v) { return v.Id === id; });
                    setSelectedVendorId(id);
                    setSelectedVendorName((vendor === null || vendor === void 0 ? void 0 : vendor.VendorName) || "");
                } },
                React.createElement("option", { value: "" }, "Select Vendor"),
                vendors.map(function (v) { return (React.createElement("option", { key: v.Id, value: v.Id }, v.VendorCode)); })),
            React.createElement("label", null, "Vendor Name"),
            React.createElement("input", { value: vendorName, readOnly: true }),
            React.createElement("label", null, "PO Number"),
            React.createElement("input", { value: poNumber, readOnly: true }),
            React.createElement("label", null, "PO Date"),
            React.createElement("input", { type: "date", value: poDate, readOnly: true }),
            React.createElement("label", null, "PO Terms"),
            React.createElement("input", { value: poTerms, readOnly: true })),
        React.createElement("div", { className: "section" },
            React.createElement("h3", null, "Amount"),
            React.createElement("label", null, "PO Amount"),
            React.createElement("input", { value: poAmount, readOnly: true }),
            React.createElement("label", null, "Advance Amount"),
            React.createElement("input", { value: advanceAmount, readOnly: true }),
            React.createElement("label", null, "Paid Amount"),
            React.createElement("input", { value: paidAmount, readOnly: true })),
        React.createElement("div", { className: "section" },
            React.createElement("h3", null, "Advance Details"),
            React.createElement("label", null, "Expected Date"),
            React.createElement("input", { type: "date", value: expectedDate, readOnly: true }),
            React.createElement("label", null, "PIC Name"),
            React.createElement(PeoplePicker_1.PeoplePicker, { context: peoplePickerContext, personSelectionLimit: 1, disabled: true, principalTypes: [PeoplePicker_1.PrincipalType.User], defaultSelectedUsers: ((_d = formData === null || formData === void 0 ? void 0 : formData.PICName) === null || _d === void 0 ? void 0 : _d.Title) ? [formData.PICName.Title] : [] }),
            React.createElement("label", null, "GL Code"),
            React.createElement("input", { value: glCode, readOnly: true }),
            React.createElement("label", null, "Cost Center"),
            React.createElement("input", { value: costCenter, readOnly: true })),
        React.createElement("div", { className: "section" },
            React.createElement("h3", null, "Remarks"),
            React.createElement("textarea", { value: remarks, readOnly: true }),
            React.createElement("h3", null, "Project Description"),
            React.createElement("textarea", { value: projectDesc, readOnly: true })),
        React.createElement("div", { className: "section" },
            React.createElement("h3", null, "Approver Details"),
            React.createElement("label", null, "Approver Remarks"),
            React.createElement("textarea", { value: approverRemarks, readOnly: true }),
            React.createElement("label", null, "Voucher Date"),
            React.createElement("input", { type: "date", value: voucherDate, readOnly: true }),
            React.createElement("label", null, "Voucher Number"),
            React.createElement("input", { value: VouchingNumber, readOnly: true }),
            React.createElement("label", null, "UTR Date"),
            React.createElement("input", { type: "date", value: UTRDate, readOnly: true }),
            React.createElement("label", null, "UTR Number"),
            React.createElement("input", { value: UTRNumber, readOnly: true })),
        React.createElement("div", { className: "section" },
            React.createElement("h3", null, "Attachments"),
            attachments.length > 0 && (React.createElement("ul", null, attachments.map(function (file, index) { return (React.createElement("li", { key: index },
                React.createElement("a", { href: file.ServerRelativeUrl, target: "_blank", rel: "noopener noreferrer" }, file.Name))); }))),
            React.createElement("div", { className: "section" },
                React.createElement("h3", null, "Workflow History"),
                workflowHistory.length === 0 ? (React.createElement("p", null, "No history available")) : (React.createElement("div", { className: "workflow-history" }, workflowHistory.map(function (h, index) { return (React.createElement("div", { key: index, className: "history-item" },
                    React.createElement("div", null,
                        h.ActionTaken === "Submitted" && "📩 ",
                        h.ActionTaken === "Approved" && "✅ ",
                        h.ActionTaken === "Rejected" && "❌ ",
                        h.ActionTaken === "Send Back" && "↩ ",
                        h.ActionTaken === "Vouched" && "💰 ",
                        h.ActionTaken === "Paid" && "💸 ",
                        h.ActionTaken),
                    React.createElement("div", null,
                        React.createElement("b", null, h.CurrentApprover)),
                    React.createElement("div", null, h.Comment),
                    React.createElement("div", { className: "date" }, new Date(h.Date).toLocaleString()))); }))))),
        React.createElement("div", { style: { textAlign: "center", marginTop: "20px" } },
            React.createElement("button", { onClick: handleExit }, "Back"))));
};
exports.default = ViewAdvanceForm;
//# sourceMappingURL=ViewAdvanceForm.js.map